#################################################
# 
# Name:           data exploration
# Programmer:     Thomas Quettier
# Date:           08/11/2024
# Description:    check stroop data
#
#################################################

rm(list=ls()) # remove all objects

# Packages ----------------------------------------------------------------

library(tidyverse)
library(ggplot2)

# Functions ---------------------------------------------------------------

devtools::load_all()

# loading data ------------------------------------------------------------
dataset_concatenation("dataset")
load("data/dataset.RData") 

# data blocco italiano
ITA<-dataset%>%
  filter(trial_kb_2.corr == 1, Loop_ita.thisRepN == 0)%>%
  group_by(participant)%>%
  summarise(mean.corr = mean(trial_kb_2.corr, na.rm = TRUE),
            mean.rt = mean(trial_kb_2.rt, na.rm = TRUE),
            sum.corr = sum(trial_kb_2.corr, na.rm = TRUE),
            sum.rt = sum(trial_kb_2.rt, na.rm = TRUE)) %>%
  mutate(Acc = (mean.corr)*100 ,
         blocco = "ITA")
            
ENG<-dataset%>%
  filter(trial_kb.corr == 1, Loop_eng.thisRepN == 0)%>%
  group_by(participant)%>%
  summarise(mean.corr = mean(trial_kb.corr, na.rm = TRUE),
            mean.rt = mean(trial_kb.rt, na.rm = TRUE),
            sum.corr = sum(trial_kb.corr, na.rm = TRUE),
            sum.rt = sum(trial_kb.rt, na.rm = TRUE)) %>%
  mutate(Acc = (mean.corr)*100 ,
         blocco = "ENG")

# unico dataset intaliano inglese
data<- rbind(ITA,ENG)

# plots  ------------------------------------------------------------

# Reaction Time
data%>%
  select(-Acc)%>%
  group_by(blocco)%>%
  ggplot(aes(x=blocco, y=mean.rt, fill = blocco)) +
  geom_bar(  stat="identity", position = position_dodge(width = 0.9))

# Accuracy
data%>%
  select(-mean.rt)%>%
  group_by(blocco)%>%
  ggplot(aes(x=blocco, y=Acc, fill = blocco)) +
  geom_bar(  stat="identity", position = position_dodge(width = 0.9))

#################################################
# 
# END
#
#################################################