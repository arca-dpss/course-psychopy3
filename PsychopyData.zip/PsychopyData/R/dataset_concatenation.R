#################################################
# 
# Name:           Psychopy dataset
# Programmer:     Thomas Quettier
# Date:           18/11/2021
# Description:    Put together several csv files
#
#################################################
dataset_concatenation <- function(dataset_name)
{

# packages
library(tidyverse)

# find nb of file
folder_dir<-c("data/")

#concatenate all file
dataset<-list.files(path=folder_dir, full.names = TRUE) %>%
  lapply(.,function(x) read.csv(x, sep=",", header=TRUE,stringsAsFactors = FALSE ))%>%
  bind_rows(.id = "participant")%>%
  mutate(across(where(is.character), str_remove_all, pattern = "[\\[|\\] ']"))

# save data
save(dataset,file= paste0("data/",dataset_name,".RData"))



} #end function  

#################################################
# 
# END
#
#################################################