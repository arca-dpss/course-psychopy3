﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.1.4),
    on Wed Nov  6 08:50:04 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.1.4'
expName = 'stroop'  # from the Builder filename that created this script
expInfo = {
    'gender (m/f)': 'f',
    'age': '',
    'participant': '',
}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data' + os.sep + '%s_%s' %(expInfo['participant'], expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/thomasquettier/Desktop/ARCA_Psychopy/stroop_Bilingue/stroop_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1680, 1050], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='norm')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# Setup ioHub
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# Initialize components for Routine "ISTR_PRACTICE"
ISTR_PRACTICEClock = core.Clock()
text_4 = visual.TextStim(win=win, name='text_4',
    text="Please press;\nLeft for red LETTERS\nDown for green LETTERS\nRight for blue LETTERS\n(Esc will quit)\n\nLet's start with a few practice trials\n\nPress any key to continue",
    font='Open Sans',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_6 = keyboard.Keyboard()

# Initialize components for Routine "TRIAL_ITA"
TRIAL_ITAClock = core.Clock()
trial_txt_2 = visual.TextStim(win=win, name='trial_txt_2',
    text='',
    font='Arial',
    pos=[0, 0], height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
trial_kb_2 = keyboard.Keyboard()

# Initialize components for Routine "FEEDBACK"
FEEDBACKClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "ISTR_ENG"
ISTR_ENGClock = core.Clock()
istr_txt = visual.TextStim(win=win, name='istr_txt',
    text='OK. Ready for the real thing?\n\nRemember, ignore the word itself; press:\nLeft for red LETTERS\nDown for green LETTERS\nRight for blue LETTERS\n(Esc will quit)\n\nPress any key to continue',
    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None, ori=0, 
    color=[1, 1, 1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
istr_kb = keyboard.Keyboard()

# Initialize components for Routine "TRIAL_ENG"
TRIAL_ENGClock = core.Clock()
trial_txt = visual.TextStim(win=win, name='trial_txt',
    text='',
    font='Arial',
    pos=[0, 0], height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
trial_kb = keyboard.Keyboard()

# Initialize components for Routine "ISTR_ITA"
ISTR_ITAClock = core.Clock()
istr_txt_2 = visual.TextStim(win=win, name='istr_txt_2',
    text='OK. Pronto per la prova vera?\n\nRicorda, ignora la parola stessa; premi: Sinistra per LETTERE rosse\nGiù per LETTERE verdi\nDestra per LETTERE blu\n(Esc per uscire)\n\nPremi un tasto qualsiasi per continuare',
    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None, ori=0, 
    color=[1, 1, 1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
istr_kb_2 = keyboard.Keyboard()

# Initialize components for Routine "TRIAL_ITA"
TRIAL_ITAClock = core.Clock()
trial_txt_2 = visual.TextStim(win=win, name='trial_txt_2',
    text='',
    font='Arial',
    pos=[0, 0], height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
trial_kb_2 = keyboard.Keyboard()

# Initialize components for Routine "THANKS"
THANKSClock = core.Clock()
thanks_txt = visual.TextStim(win=win, name='thanks_txt',
    text='This is the end of the experiment.\n\nThanks!',
    font='arial',
    pos=[0, 0], height=0.3, wrapWidth=None, ori=0, 
    color=[1, 1, 1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "ISTR_PRACTICE"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_6.keys = []
key_resp_6.rt = []
_key_resp_6_allKeys = []
# keep track of which components have finished
ISTR_PRACTICEComponents = [text_4, key_resp_6]
for thisComponent in ISTR_PRACTICEComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ISTR_PRACTICEClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ISTR_PRACTICE"-------
while continueRoutine:
    # get current time
    t = ISTR_PRACTICEClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ISTR_PRACTICEClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_4* updates
    if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_4.frameNStart = frameN  # exact frame index
        text_4.tStart = t  # local t and not account for scr refresh
        text_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
        text_4.setAutoDraw(True)
    
    # *key_resp_6* updates
    waitOnFlip = False
    if key_resp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_6.frameNStart = frameN  # exact frame index
        key_resp_6.tStart = t  # local t and not account for scr refresh
        key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
        key_resp_6.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_6.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_6.getKeys(keyList=["space"], waitRelease=False)
        _key_resp_6_allKeys.extend(theseKeys)
        if len(_key_resp_6_allKeys):
            key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
            key_resp_6.rt = _key_resp_6_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ISTR_PRACTICEComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ISTR_PRACTICE"-------
for thisComponent in ISTR_PRACTICEComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_4.started', text_4.tStartRefresh)
thisExp.addData('text_4.stopped', text_4.tStopRefresh)
# the Routine "ISTR_PRACTICE" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Loop_pracrice = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('conditions.xlsx'),
    seed=None, name='Loop_pracrice')
thisExp.addLoop(Loop_pracrice)  # add the loop to the experiment
thisLoop_pracrice = Loop_pracrice.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoop_pracrice.rgb)
if thisLoop_pracrice != None:
    for paramName in thisLoop_pracrice:
        exec('{} = thisLoop_pracrice[paramName]'.format(paramName))

for thisLoop_pracrice in Loop_pracrice:
    currentLoop = Loop_pracrice
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_pracrice.rgb)
    if thisLoop_pracrice != None:
        for paramName in thisLoop_pracrice:
            exec('{} = thisLoop_pracrice[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "TRIAL_ITA"-------
    continueRoutine = True
    # update component parameters for each repeat
    trial_txt_2.setColor(letterColor, colorSpace='rgb')
    trial_txt_2.setText(parola)
    trial_kb_2.keys = []
    trial_kb_2.rt = []
    _trial_kb_2_allKeys = []
    # keep track of which components have finished
    TRIAL_ITAComponents = [trial_txt_2, trial_kb_2]
    for thisComponent in TRIAL_ITAComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    TRIAL_ITAClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "TRIAL_ITA"-------
    while continueRoutine:
        # get current time
        t = TRIAL_ITAClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=TRIAL_ITAClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *trial_txt_2* updates
        if trial_txt_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            trial_txt_2.frameNStart = frameN  # exact frame index
            trial_txt_2.tStart = t  # local t and not account for scr refresh
            trial_txt_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(trial_txt_2, 'tStartRefresh')  # time at next scr refresh
            trial_txt_2.setAutoDraw(True)
        
        # *trial_kb_2* updates
        waitOnFlip = False
        if trial_kb_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            trial_kb_2.frameNStart = frameN  # exact frame index
            trial_kb_2.tStart = t  # local t and not account for scr refresh
            trial_kb_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(trial_kb_2, 'tStartRefresh')  # time at next scr refresh
            trial_kb_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(trial_kb_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(trial_kb_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if trial_kb_2.status == STARTED and not waitOnFlip:
            theseKeys = trial_kb_2.getKeys(keyList=["left","down","right"], waitRelease=False)
            _trial_kb_2_allKeys.extend(theseKeys)
            if len(_trial_kb_2_allKeys):
                trial_kb_2.keys = _trial_kb_2_allKeys[-1].name  # just the last key pressed
                trial_kb_2.rt = _trial_kb_2_allKeys[-1].rt
                # was this correct?
                if (trial_kb_2.keys == str(corrAns)) or (trial_kb_2.keys == corrAns):
                    trial_kb_2.corr = 1
                else:
                    trial_kb_2.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TRIAL_ITAComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "TRIAL_ITA"-------
    for thisComponent in TRIAL_ITAComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Loop_pracrice.addData('trial_txt_2.started', trial_txt_2.tStartRefresh)
    Loop_pracrice.addData('trial_txt_2.stopped', trial_txt_2.tStopRefresh)
    # check responses
    if trial_kb_2.keys in ['', [], None]:  # No response was made
        trial_kb_2.keys = None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           trial_kb_2.corr = 1;  # correct non-response
        else:
           trial_kb_2.corr = 0;  # failed to respond (incorrectly)
    # store data for Loop_pracrice (TrialHandler)
    Loop_pracrice.addData('trial_kb_2.keys',trial_kb_2.keys)
    Loop_pracrice.addData('trial_kb_2.corr', trial_kb_2.corr)
    if trial_kb_2.keys != None:  # we had a response
        Loop_pracrice.addData('trial_kb_2.rt', trial_kb_2.rt)
    Loop_pracrice.addData('trial_kb_2.started', trial_kb_2.tStartRefresh)
    Loop_pracrice.addData('trial_kb_2.stopped', trial_kb_2.tStopRefresh)
    # the Routine "TRIAL_ITA" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "FEEDBACK"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    if trial_kb_2.corr:
        msg = "Bravo! RT={:.3f}".format(trial_kb_2.rt)
    else:
        msg = "Oops! sbagliato"
    text.setText(msg)
    # keep track of which components have finished
    FEEDBACKComponents = [text]
    for thisComponent in FEEDBACKComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    FEEDBACKClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "FEEDBACK"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = FEEDBACKClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=FEEDBACKClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in FEEDBACKComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "FEEDBACK"-------
    for thisComponent in FEEDBACKComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Loop_pracrice.addData('text.started', text.tStartRefresh)
    Loop_pracrice.addData('text.stopped', text.tStopRefresh)
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'Loop_pracrice'


# ------Prepare to start Routine "ISTR_ENG"-------
continueRoutine = True
# update component parameters for each repeat
istr_kb.keys = []
istr_kb.rt = []
_istr_kb_allKeys = []
# keep track of which components have finished
ISTR_ENGComponents = [istr_txt, istr_kb]
for thisComponent in ISTR_ENGComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ISTR_ENGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ISTR_ENG"-------
while continueRoutine:
    # get current time
    t = ISTR_ENGClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ISTR_ENGClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *istr_txt* updates
    if istr_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        istr_txt.frameNStart = frameN  # exact frame index
        istr_txt.tStart = t  # local t and not account for scr refresh
        istr_txt.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(istr_txt, 'tStartRefresh')  # time at next scr refresh
        istr_txt.setAutoDraw(True)
    
    # *istr_kb* updates
    waitOnFlip = False
    if istr_kb.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        istr_kb.frameNStart = frameN  # exact frame index
        istr_kb.tStart = t  # local t and not account for scr refresh
        istr_kb.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(istr_kb, 'tStartRefresh')  # time at next scr refresh
        istr_kb.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(istr_kb.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(istr_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if istr_kb.status == STARTED and not waitOnFlip:
        theseKeys = istr_kb.getKeys(keyList=None, waitRelease=False)
        _istr_kb_allKeys.extend(theseKeys)
        if len(_istr_kb_allKeys):
            istr_kb.keys = _istr_kb_allKeys[-1].name  # just the last key pressed
            istr_kb.rt = _istr_kb_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ISTR_ENGComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ISTR_ENG"-------
for thisComponent in ISTR_ENGComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "ISTR_ENG" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Loop_eng = data.TrialHandler(nReps=0.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('conditions.xlsx'),
    seed=None, name='Loop_eng')
thisExp.addLoop(Loop_eng)  # add the loop to the experiment
thisLoop_eng = Loop_eng.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoop_eng.rgb)
if thisLoop_eng != None:
    for paramName in thisLoop_eng:
        exec('{} = thisLoop_eng[paramName]'.format(paramName))

for thisLoop_eng in Loop_eng:
    currentLoop = Loop_eng
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_eng.rgb)
    if thisLoop_eng != None:
        for paramName in thisLoop_eng:
            exec('{} = thisLoop_eng[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "TRIAL_ENG"-------
    continueRoutine = True
    # update component parameters for each repeat
    trial_txt.setColor(letterColor, colorSpace='rgb')
    trial_txt.setText(word)
    trial_kb.keys = []
    trial_kb.rt = []
    _trial_kb_allKeys = []
    # keep track of which components have finished
    TRIAL_ENGComponents = [trial_txt, trial_kb]
    for thisComponent in TRIAL_ENGComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    TRIAL_ENGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "TRIAL_ENG"-------
    while continueRoutine:
        # get current time
        t = TRIAL_ENGClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=TRIAL_ENGClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *trial_txt* updates
        if trial_txt.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            trial_txt.frameNStart = frameN  # exact frame index
            trial_txt.tStart = t  # local t and not account for scr refresh
            trial_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(trial_txt, 'tStartRefresh')  # time at next scr refresh
            trial_txt.setAutoDraw(True)
        
        # *trial_kb* updates
        waitOnFlip = False
        if trial_kb.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            trial_kb.frameNStart = frameN  # exact frame index
            trial_kb.tStart = t  # local t and not account for scr refresh
            trial_kb.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(trial_kb, 'tStartRefresh')  # time at next scr refresh
            trial_kb.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(trial_kb.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(trial_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if trial_kb.status == STARTED and not waitOnFlip:
            theseKeys = trial_kb.getKeys(keyList=["left","down","right"], waitRelease=False)
            _trial_kb_allKeys.extend(theseKeys)
            if len(_trial_kb_allKeys):
                trial_kb.keys = _trial_kb_allKeys[-1].name  # just the last key pressed
                trial_kb.rt = _trial_kb_allKeys[-1].rt
                # was this correct?
                if (trial_kb.keys == str(corrAns)) or (trial_kb.keys == corrAns):
                    trial_kb.corr = 1
                else:
                    trial_kb.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TRIAL_ENGComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "TRIAL_ENG"-------
    for thisComponent in TRIAL_ENGComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Loop_eng.addData('trial_txt.started', trial_txt.tStartRefresh)
    Loop_eng.addData('trial_txt.stopped', trial_txt.tStopRefresh)
    # check responses
    if trial_kb.keys in ['', [], None]:  # No response was made
        trial_kb.keys = None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           trial_kb.corr = 1;  # correct non-response
        else:
           trial_kb.corr = 0;  # failed to respond (incorrectly)
    # store data for Loop_eng (TrialHandler)
    Loop_eng.addData('trial_kb.keys',trial_kb.keys)
    Loop_eng.addData('trial_kb.corr', trial_kb.corr)
    if trial_kb.keys != None:  # we had a response
        Loop_eng.addData('trial_kb.rt', trial_kb.rt)
    Loop_eng.addData('trial_kb.started', trial_kb.tStartRefresh)
    Loop_eng.addData('trial_kb.stopped', trial_kb.tStopRefresh)
    # the Routine "TRIAL_ENG" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 0.0 repeats of 'Loop_eng'


# ------Prepare to start Routine "ISTR_ITA"-------
continueRoutine = True
# update component parameters for each repeat
istr_kb_2.keys = []
istr_kb_2.rt = []
_istr_kb_2_allKeys = []
# keep track of which components have finished
ISTR_ITAComponents = [istr_txt_2, istr_kb_2]
for thisComponent in ISTR_ITAComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ISTR_ITAClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ISTR_ITA"-------
while continueRoutine:
    # get current time
    t = ISTR_ITAClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ISTR_ITAClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *istr_txt_2* updates
    if istr_txt_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        istr_txt_2.frameNStart = frameN  # exact frame index
        istr_txt_2.tStart = t  # local t and not account for scr refresh
        istr_txt_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(istr_txt_2, 'tStartRefresh')  # time at next scr refresh
        istr_txt_2.setAutoDraw(True)
    
    # *istr_kb_2* updates
    waitOnFlip = False
    if istr_kb_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        istr_kb_2.frameNStart = frameN  # exact frame index
        istr_kb_2.tStart = t  # local t and not account for scr refresh
        istr_kb_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(istr_kb_2, 'tStartRefresh')  # time at next scr refresh
        istr_kb_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(istr_kb_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(istr_kb_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if istr_kb_2.status == STARTED and not waitOnFlip:
        theseKeys = istr_kb_2.getKeys(keyList=None, waitRelease=False)
        _istr_kb_2_allKeys.extend(theseKeys)
        if len(_istr_kb_2_allKeys):
            istr_kb_2.keys = _istr_kb_2_allKeys[-1].name  # just the last key pressed
            istr_kb_2.rt = _istr_kb_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ISTR_ITAComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ISTR_ITA"-------
for thisComponent in ISTR_ITAComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "ISTR_ITA" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Loop_ita = data.TrialHandler(nReps=5.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('conditions.xlsx'),
    seed=None, name='Loop_ita')
thisExp.addLoop(Loop_ita)  # add the loop to the experiment
thisLoop_ita = Loop_ita.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoop_ita.rgb)
if thisLoop_ita != None:
    for paramName in thisLoop_ita:
        exec('{} = thisLoop_ita[paramName]'.format(paramName))

for thisLoop_ita in Loop_ita:
    currentLoop = Loop_ita
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_ita.rgb)
    if thisLoop_ita != None:
        for paramName in thisLoop_ita:
            exec('{} = thisLoop_ita[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "TRIAL_ITA"-------
    continueRoutine = True
    # update component parameters for each repeat
    trial_txt_2.setColor(letterColor, colorSpace='rgb')
    trial_txt_2.setText(parola)
    trial_kb_2.keys = []
    trial_kb_2.rt = []
    _trial_kb_2_allKeys = []
    # keep track of which components have finished
    TRIAL_ITAComponents = [trial_txt_2, trial_kb_2]
    for thisComponent in TRIAL_ITAComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    TRIAL_ITAClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "TRIAL_ITA"-------
    while continueRoutine:
        # get current time
        t = TRIAL_ITAClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=TRIAL_ITAClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *trial_txt_2* updates
        if trial_txt_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            trial_txt_2.frameNStart = frameN  # exact frame index
            trial_txt_2.tStart = t  # local t and not account for scr refresh
            trial_txt_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(trial_txt_2, 'tStartRefresh')  # time at next scr refresh
            trial_txt_2.setAutoDraw(True)
        
        # *trial_kb_2* updates
        waitOnFlip = False
        if trial_kb_2.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            trial_kb_2.frameNStart = frameN  # exact frame index
            trial_kb_2.tStart = t  # local t and not account for scr refresh
            trial_kb_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(trial_kb_2, 'tStartRefresh')  # time at next scr refresh
            trial_kb_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(trial_kb_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(trial_kb_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if trial_kb_2.status == STARTED and not waitOnFlip:
            theseKeys = trial_kb_2.getKeys(keyList=["left","down","right"], waitRelease=False)
            _trial_kb_2_allKeys.extend(theseKeys)
            if len(_trial_kb_2_allKeys):
                trial_kb_2.keys = _trial_kb_2_allKeys[-1].name  # just the last key pressed
                trial_kb_2.rt = _trial_kb_2_allKeys[-1].rt
                # was this correct?
                if (trial_kb_2.keys == str(corrAns)) or (trial_kb_2.keys == corrAns):
                    trial_kb_2.corr = 1
                else:
                    trial_kb_2.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in TRIAL_ITAComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "TRIAL_ITA"-------
    for thisComponent in TRIAL_ITAComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Loop_ita.addData('trial_txt_2.started', trial_txt_2.tStartRefresh)
    Loop_ita.addData('trial_txt_2.stopped', trial_txt_2.tStopRefresh)
    # check responses
    if trial_kb_2.keys in ['', [], None]:  # No response was made
        trial_kb_2.keys = None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           trial_kb_2.corr = 1;  # correct non-response
        else:
           trial_kb_2.corr = 0;  # failed to respond (incorrectly)
    # store data for Loop_ita (TrialHandler)
    Loop_ita.addData('trial_kb_2.keys',trial_kb_2.keys)
    Loop_ita.addData('trial_kb_2.corr', trial_kb_2.corr)
    if trial_kb_2.keys != None:  # we had a response
        Loop_ita.addData('trial_kb_2.rt', trial_kb_2.rt)
    Loop_ita.addData('trial_kb_2.started', trial_kb_2.tStartRefresh)
    Loop_ita.addData('trial_kb_2.stopped', trial_kb_2.tStopRefresh)
    # the Routine "TRIAL_ITA" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 5.0 repeats of 'Loop_ita'


# ------Prepare to start Routine "THANKS"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
THANKSComponents = [thanks_txt]
for thisComponent in THANKSComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
THANKSClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "THANKS"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = THANKSClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=THANKSClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *thanks_txt* updates
    if thanks_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        thanks_txt.frameNStart = frameN  # exact frame index
        thanks_txt.tStart = t  # local t and not account for scr refresh
        thanks_txt.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(thanks_txt, 'tStartRefresh')  # time at next scr refresh
        thanks_txt.setAutoDraw(True)
    if thanks_txt.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > thanks_txt.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            thanks_txt.tStop = t  # not accounting for scr refresh
            thanks_txt.frameNStop = frameN  # exact frame index
            win.timeOnFlip(thanks_txt, 'tStopRefresh')  # time at next scr refresh
            thanks_txt.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in THANKSComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "THANKS"-------
for thisComponent in THANKSComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('thanks_txt.started', thanks_txt.tStartRefresh)
thisExp.addData('thanks_txt.stopped', thanks_txt.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
