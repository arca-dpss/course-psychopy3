 Experiment:     	STROOP ENG 1.0
============================================================
 Programmer:     	Thomas Quettier
============================================================
 Date:           	16/11/2021
============================================================
 Description:    	Stroop biligual test con PsychoPy
============================================================

ATTENZIONE
------------------------

Il test è in lingua italiana ed inglese
Il controbilanciamento è previsto in base al numero del partecipante
Il blocco di allenamento si può evitare con impostazione pari a 0

Analyzing your data
------------------------
Si può usare la cartella R per creare il dataset ed esplorarlo.
Bisogna spostare i files partecipanti nella cartella data di R



Version updating:
------------------------
