 Experiment:     	STROOP valutazione ARCA
============================================================
 Programmer:     	Metti qui il tuo nome
============================================================
 Date:           	21/10/2022
============================================================
 Description:    	Test per la valutazione del corso ARCA
============================================================

Compito
------------------------

- Ricostruire il lo Stroop
- Certi componenti sono disponibili nella lista componenti
- Bisognera ricreare certi loops

Il test deve avere: 
------------------------

- Una routine con due immagini cliccabile per dire se il partecipante è madrelingua inglese o italiana.
- Un blocco pratica (Il feedback non è necessario ma poi copiarlo altrove)
- Un blocco ENG
- Un blocco ITA
- Apposite istruzioni
- Controbilanciato automatico ENG e ITA in base al numero del partecipante


Valutazione
------------------------
- Vai il più avanti possibile. 
- Quando non arrivi ad andare avanti chiama l'istruttore
- Quando funziona creare una cartella nome.cognome e conservare l'esperimento (chiedimi la chiavetta usb)

