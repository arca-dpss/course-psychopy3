 Experiment:     	STROOP ENG ITA 1.0
============================================================
 Programmer:     	Thomas Quettier
============================================================
 Date:           	18/04/2023
============================================================
 Description:    	Stroop biligual test con PsychoPy
============================================================

ATTENZIONE
------------------------

Il test è in lingua italiana ed inglese




Version updating:
------------------------
