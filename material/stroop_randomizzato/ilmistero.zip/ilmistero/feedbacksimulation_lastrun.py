﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.1.4),
    on Tue Apr 18 20:46:48 2023
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.1.4'
expName = 'VR_setting'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
    'practice': '1',
    'experimenter': 'Giulia',
}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/thomasquettier/Desktop/ilmistero/feedbacksimulation_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1680, 1050], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='VRmonitor', color=[-1,-1,-1], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='cm')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# Setup ioHub
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# Initialize components for Routine "SETTING"
SETTINGClock = core.Clock()
# setting image size
size_img = 10

# setting trials
trial_duration = 0.2
training_duration = 0.1
fixationpoint = 0.1
blackscreen = 0.1
stim_rep = 1

count = 0

# Initialize components for Routine "ISTR_RIVALRY"
ISTR_RIVALRYClock = core.Clock()
txt_istr_rivalry = visual.TextStim(win=win, name='txt_istr_rivalry',
    text='Adesso devi osservare il punto di fissazione e dire a voce alta quello che vedi in tempo reale:\n\nIn alcune prove potrai vedere un viso SORRIDENTE o NEUTRO, in altre dei FIORI o dei CONTAINERS.\n\nTi chiedo di non esplorare lo schermo ma rimanere concentrata/o sul punto di fissazione.\n\nPremi spazio per proseguire.',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
kb_istr_rivalry = keyboard.Keyboard()

# Initialize components for Routine "FIXATION"
FIXATIONClock = core.Clock()
img_fixation = visual.ImageStim(
    win=win,
    name='img_fixation', 
    image='images/Fissazione.png', mask=None, anchor='center',
    ori=0.0, pos=[0,0], size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "RIVALRY"
RIVALRYClock = core.Clock()
img_rivalry = visual.ImageStim(
    win=win,
    name='img_rivalry', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "BLACK_SCREEN"
BLACK_SCREENClock = core.Clock()
txt_black_training = visual.TextStim(win=win, name='txt_black_training',
    text=' ',
    font='Open Sans',
    pos=(0, 0), height=0.5, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "ISTR_TRAINING"
ISTR_TRAININGClock = core.Clock()
txt_training = visual.TextStim(win=win, name='txt_training',
    text="Adesso il tuo compito sara di indicare quello che vedi con la tastiera con i tasti 'j','k','l'.\n\nAppoggi la mano destra sui tasti.\n\nPremi spazio per proseguire.",
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
kb_training = keyboard.Keyboard()

# Initialize components for Routine "ISTR_CODING"
ISTR_CODINGClock = core.Clock()
kb_istr_coding = keyboard.Keyboard()
img_istr_coding = visual.ImageStim(
    win=win,
    name='img_istr_coding', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
txt_coding_1 = visual.TextStim(win=win, name='txt_coding_1',
    text='',
    font='Open Sans',
    pos=(-10, 3), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
txt_coding_2 = visual.TextStim(win=win, name='txt_coding_2',
    text='',
    font='Open Sans',
    pos=(-10, 1), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
txt_coding_3 = visual.TextStim(win=win, name='txt_coding_3',
    text='',
    font='Open Sans',
    pos=(10, 3), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
txt_coding_4 = visual.TextStim(win=win, name='txt_coding_4',
    text='',
    font='Open Sans',
    pos=(10, 1), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);

# Initialize components for Routine "FIXATION_TRAINING"
FIXATION_TRAININGClock = core.Clock()
img_fixation_training = visual.ImageStim(
    win=win,
    name='img_fixation_training', 
    image='images/Fissazione.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "TRIAL_TRAINING"
TRIAL_TRAININGClock = core.Clock()
img_istr_training = visual.ImageStim(
    win=win,
    name='img_istr_training', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
kb_trial_training = keyboard.Keyboard()

# Initialize components for Routine "FEEDBACK"
FEEDBACKClock = core.Clock()
txt_feedback = visual.TextStim(win=win, name='txt_feedback',
    text='',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "BREAK"
BREAKClock = core.Clock()
txt_break = visual.TextStim(win=win, name='txt_break',
    text="Pausa.\n\nPremi 'spazio' per proseguire.",
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
kb_pausa = keyboard.Keyboard()

# Initialize components for Routine "ACCURACY"
ACCURACYClock = core.Clock()
txt_accuracy = visual.TextStim(win=win, name='txt_accuracy',
    text='',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
kb_accuracy = keyboard.Keyboard()

# Initialize components for Routine "EXTRA_TRAINING"
EXTRA_TRAININGClock = core.Clock()
kb_extra_training = keyboard.Keyboard()
txt_extra_training = visual.TextStim(win=win, name='txt_extra_training',
    text="Vuoi fare piu \npratica ?\n\n'n' : no\n's' : si",
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "ISTR_EXPERIMENT"
ISTR_EXPERIMENTClock = core.Clock()
text_exp_left = visual.TextStim(win=win, name='text_exp_left',
    text="Adesso inizia l'esperimento.",
    font='Open Sans',
    pos=[0,0], height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
kb_experiment = keyboard.Keyboard()

# Initialize components for Routine "ISTR_MIMICRY"
ISTR_MIMICRYClock = core.Clock()
txt_mimicry = visual.TextStim(win=win, name='txt_mimicry',
    text='',
    font='Open Sans',
    pos=(0, 5), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
kb_mimicry = keyboard.Keyboard()
img_mimicry = visual.ImageStim(
    win=win,
    name='img_mimicry', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, -2), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)

# Initialize components for Routine "ISTR_CODING"
ISTR_CODINGClock = core.Clock()
kb_istr_coding = keyboard.Keyboard()
img_istr_coding = visual.ImageStim(
    win=win,
    name='img_istr_coding', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
txt_coding_1 = visual.TextStim(win=win, name='txt_coding_1',
    text='',
    font='Open Sans',
    pos=(-10, 3), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
txt_coding_2 = visual.TextStim(win=win, name='txt_coding_2',
    text='',
    font='Open Sans',
    pos=(-10, 1), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
txt_coding_3 = visual.TextStim(win=win, name='txt_coding_3',
    text='',
    font='Open Sans',
    pos=(10, 3), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
txt_coding_4 = visual.TextStim(win=win, name='txt_coding_4',
    text='',
    font='Open Sans',
    pos=(10, 1), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);

# Initialize components for Routine "FIXATION"
FIXATIONClock = core.Clock()
img_fixation = visual.ImageStim(
    win=win,
    name='img_fixation', 
    image='images/Fissazione.png', mask=None, anchor='center',
    ori=0.0, pos=[0,0], size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "TRIAL"
TRIALClock = core.Clock()
img_trial = visual.ImageStim(
    win=win,
    name='img_trial', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
txt_istr1 = visual.TextStim(win=win, name='txt_istr1',
    text='',
    font='Open Sans',
    pos=(-20, 1), height=0.8, wrapWidth=None, ori=0.0, 
    color='gray', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
txt_istr2 = visual.TextStim(win=win, name='txt_istr2',
    text='',
    font='Open Sans',
    pos=(-20, -1), height=0.8, wrapWidth=None, ori=0.0, 
    color='gray', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
txt_istr3 = visual.TextStim(win=win, name='txt_istr3',
    text='',
    font='Open Sans',
    pos=(20, 1), height=0.8, wrapWidth=None, ori=0.0, 
    color='gray', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
txt_istr4 = visual.TextStim(win=win, name='txt_istr4',
    text='',
    font='Open Sans',
    pos=(20, -1), height=0.8, wrapWidth=None, ori=0.0, 
    color='gray', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
kb_trial = keyboard.Keyboard()

# Initialize components for Routine "BLACK_SCREEN"
BLACK_SCREENClock = core.Clock()
txt_black_training = visual.TextStim(win=win, name='txt_black_training',
    text=' ',
    font='Open Sans',
    pos=(0, 0), height=0.5, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "BREAK"
BREAKClock = core.Clock()
txt_break = visual.TextStim(win=win, name='txt_break',
    text="Pausa.\n\nPremi 'spazio' per proseguire.",
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
kb_pausa = keyboard.Keyboard()

# Initialize components for Routine "ISTR_VALUATION"
ISTR_VALUATIONClock = core.Clock()
val = "Ti chiediamo di valutare la valenza dei stimoli. "
val2 = "La scala va da -3 (negativo) a +3 (positivo)"


valb = "Ti chiediamo di valutare l'arousal dei stimoli. "
valb2 = "La scala va da 1 (per niente intenso) a 7 (molto intenso)"

txt_istr_valuation = visual.TextStim(win=win, name='txt_istr_valuation',
    text='',
    font='Open Sans',
    pos=(0, 2), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
txt_scale = visual.TextStim(win=win, name='txt_scale',
    text='',
    font='Open Sans',
    pos=(0, -2), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
kb_istr_valuation = keyboard.Keyboard()

# Initialize components for Routine "VALUATION"
VALUATIONClock = core.Clock()
img_valence = visual.ImageStim(
    win=win,
    name='img_valence', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(size_img, size_img),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
key_valuation = keyboard.Keyboard()

# Initialize components for Routine "SWITCH_COUNTERBALANCE"
SWITCH_COUNTERBALANCEClock = core.Clock()

# Initialize components for Routine "END"
ENDClock = core.Clock()
txt_end = visual.TextStim(win=win, name='txt_end',
    text='Grazie per la tua partecipazione!\n',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
kb_end = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "SETTING"-------
continueRoutine = True
# update component parameters for each repeat
nreppractice = int(expInfo["practice"])*10


num = int(expInfo["participant"]) # randomisation based on pt num

if (num % 2) == 0:
    mimicry = 1
    mimic1 = "Devi tenere lo chopstick per i prossimi blocchi."
    mimic2 = "Devi avere la mimica libera per i prossimi blocchi."
    mimimg = 'images/istruzioni/mimicry_happy.png'
else:
    mimicry = 0
    mimic1 = "Devi avere la mimica libera per i prossimi blocchi."
    mimic2 = "Devi tenere lo chopstick per i prossimi blocchi."
    mimimg = 'images/istruzioni/mimicry_neutral.png'

    
# keep track of which components have finished
SETTINGComponents = []
for thisComponent in SETTINGComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
SETTINGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "SETTING"-------
while continueRoutine:
    # get current time
    t = SETTINGClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=SETTINGClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in SETTINGComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "SETTING"-------
for thisComponent in SETTINGComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "SETTING" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "ISTR_RIVALRY"-------
continueRoutine = True
# update component parameters for each repeat
kb_istr_rivalry.keys = []
kb_istr_rivalry.rt = []
_kb_istr_rivalry_allKeys = []
# keep track of which components have finished
ISTR_RIVALRYComponents = [txt_istr_rivalry, kb_istr_rivalry]
for thisComponent in ISTR_RIVALRYComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ISTR_RIVALRYClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ISTR_RIVALRY"-------
while continueRoutine:
    # get current time
    t = ISTR_RIVALRYClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ISTR_RIVALRYClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_istr_rivalry* updates
    if txt_istr_rivalry.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        txt_istr_rivalry.frameNStart = frameN  # exact frame index
        txt_istr_rivalry.tStart = t  # local t and not account for scr refresh
        txt_istr_rivalry.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(txt_istr_rivalry, 'tStartRefresh')  # time at next scr refresh
        txt_istr_rivalry.setAutoDraw(True)
    
    # *kb_istr_rivalry* updates
    if kb_istr_rivalry.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        kb_istr_rivalry.frameNStart = frameN  # exact frame index
        kb_istr_rivalry.tStart = t  # local t and not account for scr refresh
        kb_istr_rivalry.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(kb_istr_rivalry, 'tStartRefresh')  # time at next scr refresh
        kb_istr_rivalry.status = STARTED
        # keyboard checking is just starting
        kb_istr_rivalry.clock.reset()  # now t=0
    if kb_istr_rivalry.status == STARTED:
        theseKeys = kb_istr_rivalry.getKeys(keyList=['space'], waitRelease=False)
        _kb_istr_rivalry_allKeys.extend(theseKeys)
        if len(_kb_istr_rivalry_allKeys):
            kb_istr_rivalry.keys = _kb_istr_rivalry_allKeys[-1].name  # just the last key pressed
            kb_istr_rivalry.rt = _kb_istr_rivalry_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ISTR_RIVALRYComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ISTR_RIVALRY"-------
for thisComponent in ISTR_RIVALRYComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "ISTR_RIVALRY" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Br_test_loop = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('rivalry.xlsx'),
    seed=None, name='Br_test_loop')
thisExp.addLoop(Br_test_loop)  # add the loop to the experiment
thisBr_test_loop = Br_test_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBr_test_loop.rgb)
if thisBr_test_loop != None:
    for paramName in thisBr_test_loop:
        exec('{} = thisBr_test_loop[paramName]'.format(paramName))

for thisBr_test_loop in Br_test_loop:
    currentLoop = Br_test_loop
    # abbreviate parameter names if possible (e.g. rgb = thisBr_test_loop.rgb)
    if thisBr_test_loop != None:
        for paramName in thisBr_test_loop:
            exec('{} = thisBr_test_loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "FIXATION"-------
    continueRoutine = True
    # update component parameters for each repeat
    img_fixation.setPos((0, 0))
    # keep track of which components have finished
    FIXATIONComponents = [img_fixation]
    for thisComponent in FIXATIONComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    FIXATIONClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "FIXATION"-------
    while continueRoutine:
        # get current time
        t = FIXATIONClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=FIXATIONClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *img_fixation* updates
        if img_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            img_fixation.frameNStart = frameN  # exact frame index
            img_fixation.tStart = t  # local t and not account for scr refresh
            img_fixation.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(img_fixation, 'tStartRefresh')  # time at next scr refresh
            img_fixation.setAutoDraw(True)
        if img_fixation.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > img_fixation.tStartRefresh + fixationpoint-frameTolerance:
                # keep track of stop time/frame for later
                img_fixation.tStop = t  # not accounting for scr refresh
                img_fixation.frameNStop = frameN  # exact frame index
                win.timeOnFlip(img_fixation, 'tStopRefresh')  # time at next scr refresh
                img_fixation.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in FIXATIONComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "FIXATION"-------
    for thisComponent in FIXATIONComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "FIXATION" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "RIVALRY"-------
    continueRoutine = True
    # update component parameters for each repeat
    img_rivalry.setImage(file_path)
    # keep track of which components have finished
    RIVALRYComponents = [img_rivalry]
    for thisComponent in RIVALRYComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    RIVALRYClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "RIVALRY"-------
    while continueRoutine:
        # get current time
        t = RIVALRYClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=RIVALRYClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *img_rivalry* updates
        if img_rivalry.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            img_rivalry.frameNStart = frameN  # exact frame index
            img_rivalry.tStart = t  # local t and not account for scr refresh
            img_rivalry.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(img_rivalry, 'tStartRefresh')  # time at next scr refresh
            img_rivalry.setAutoDraw(True)
        if img_rivalry.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > img_rivalry.tStartRefresh + trial_duration-frameTolerance:
                # keep track of stop time/frame for later
                img_rivalry.tStop = t  # not accounting for scr refresh
                img_rivalry.frameNStop = frameN  # exact frame index
                win.timeOnFlip(img_rivalry, 'tStopRefresh')  # time at next scr refresh
                img_rivalry.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in RIVALRYComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "RIVALRY"-------
    for thisComponent in RIVALRYComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Br_test_loop.addData('img_rivalry.started', img_rivalry.tStartRefresh)
    Br_test_loop.addData('img_rivalry.stopped', img_rivalry.tStopRefresh)
    # the Routine "RIVALRY" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "BLACK_SCREEN"-------
    continueRoutine = True
    # update component parameters for each repeat
    # keep track of which components have finished
    BLACK_SCREENComponents = [txt_black_training]
    for thisComponent in BLACK_SCREENComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    BLACK_SCREENClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "BLACK_SCREEN"-------
    while continueRoutine:
        # get current time
        t = BLACK_SCREENClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=BLACK_SCREENClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *txt_black_training* updates
        if txt_black_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            txt_black_training.frameNStart = frameN  # exact frame index
            txt_black_training.tStart = t  # local t and not account for scr refresh
            txt_black_training.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(txt_black_training, 'tStartRefresh')  # time at next scr refresh
            txt_black_training.setAutoDraw(True)
        if txt_black_training.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > txt_black_training.tStartRefresh + blackscreen-frameTolerance:
                # keep track of stop time/frame for later
                txt_black_training.tStop = t  # not accounting for scr refresh
                txt_black_training.frameNStop = frameN  # exact frame index
                win.timeOnFlip(txt_black_training, 'tStopRefresh')  # time at next scr refresh
                txt_black_training.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in BLACK_SCREENComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "BLACK_SCREEN"-------
    for thisComponent in BLACK_SCREENComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "BLACK_SCREEN" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'Br_test_loop'


# set up handler to look after randomisation of conditions etc
Training_loop = data.TrialHandler(nReps=nreppractice, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Training_loop')
thisExp.addLoop(Training_loop)  # add the loop to the experiment
thisTraining_loop = Training_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTraining_loop.rgb)
if thisTraining_loop != None:
    for paramName in thisTraining_loop:
        exec('{} = thisTraining_loop[paramName]'.format(paramName))

for thisTraining_loop in Training_loop:
    currentLoop = Training_loop
    # abbreviate parameter names if possible (e.g. rgb = thisTraining_loop.rgb)
    if thisTraining_loop != None:
        for paramName in thisTraining_loop:
            exec('{} = thisTraining_loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "ISTR_TRAINING"-------
    continueRoutine = True
    # update component parameters for each repeat
    kb_training.keys = []
    kb_training.rt = []
    _kb_training_allKeys = []
    # keep track of which components have finished
    ISTR_TRAININGComponents = [txt_training, kb_training]
    for thisComponent in ISTR_TRAININGComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ISTR_TRAININGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ISTR_TRAINING"-------
    while continueRoutine:
        # get current time
        t = ISTR_TRAININGClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ISTR_TRAININGClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *txt_training* updates
        if txt_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            txt_training.frameNStart = frameN  # exact frame index
            txt_training.tStart = t  # local t and not account for scr refresh
            txt_training.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(txt_training, 'tStartRefresh')  # time at next scr refresh
            txt_training.setAutoDraw(True)
        
        # *kb_training* updates
        if kb_training.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            kb_training.frameNStart = frameN  # exact frame index
            kb_training.tStart = t  # local t and not account for scr refresh
            kb_training.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(kb_training, 'tStartRefresh')  # time at next scr refresh
            kb_training.status = STARTED
            # keyboard checking is just starting
            kb_training.clock.reset()  # now t=0
        if kb_training.status == STARTED:
            theseKeys = kb_training.getKeys(keyList=['space'], waitRelease=False)
            _kb_training_allKeys.extend(theseKeys)
            if len(_kb_training_allKeys):
                kb_training.keys = _kb_training_allKeys[-1].name  # just the last key pressed
                kb_training.rt = _kb_training_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISTR_TRAININGComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISTR_TRAINING"-------
    for thisComponent in ISTR_TRAININGComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ISTR_TRAINING" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Training_block_loop = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('coding.xlsx'),
        seed=None, name='Training_block_loop')
    thisExp.addLoop(Training_block_loop)  # add the loop to the experiment
    thisTraining_block_loop = Training_block_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTraining_block_loop.rgb)
    if thisTraining_block_loop != None:
        for paramName in thisTraining_block_loop:
            exec('{} = thisTraining_block_loop[paramName]'.format(paramName))
    
    for thisTraining_block_loop in Training_block_loop:
        currentLoop = Training_block_loop
        # abbreviate parameter names if possible (e.g. rgb = thisTraining_block_loop.rgb)
        if thisTraining_block_loop != None:
            for paramName in thisTraining_block_loop:
                exec('{} = thisTraining_block_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "ISTR_CODING"-------
        continueRoutine = True
        # update component parameters for each repeat
        kb_istr_coding.keys = []
        kb_istr_coding.rt = []
        _kb_istr_coding_allKeys = []
        img_istr_coding.setImage(Istr_path)
        txt_coding_1.setText(istr_index1)
        txt_coding_2.setText(istr_index2)
        txt_coding_3.setText(istr_index3)
        txt_coding_4.setText(istr_index4)
        # keep track of which components have finished
        ISTR_CODINGComponents = [kb_istr_coding, img_istr_coding, txt_coding_1, txt_coding_2, txt_coding_3, txt_coding_4]
        for thisComponent in ISTR_CODINGComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        ISTR_CODINGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "ISTR_CODING"-------
        while continueRoutine:
            # get current time
            t = ISTR_CODINGClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=ISTR_CODINGClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *kb_istr_coding* updates
            waitOnFlip = False
            if kb_istr_coding.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                kb_istr_coding.frameNStart = frameN  # exact frame index
                kb_istr_coding.tStart = t  # local t and not account for scr refresh
                kb_istr_coding.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(kb_istr_coding, 'tStartRefresh')  # time at next scr refresh
                kb_istr_coding.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(kb_istr_coding.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(kb_istr_coding.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if kb_istr_coding.status == STARTED and not waitOnFlip:
                theseKeys = kb_istr_coding.getKeys(keyList=['space'], waitRelease=False)
                _kb_istr_coding_allKeys.extend(theseKeys)
                if len(_kb_istr_coding_allKeys):
                    kb_istr_coding.keys = _kb_istr_coding_allKeys[-1].name  # just the last key pressed
                    kb_istr_coding.rt = _kb_istr_coding_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # *img_istr_coding* updates
            if img_istr_coding.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                img_istr_coding.frameNStart = frameN  # exact frame index
                img_istr_coding.tStart = t  # local t and not account for scr refresh
                img_istr_coding.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(img_istr_coding, 'tStartRefresh')  # time at next scr refresh
                img_istr_coding.setAutoDraw(True)
            
            # *txt_coding_1* updates
            if txt_coding_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_1.frameNStart = frameN  # exact frame index
                txt_coding_1.tStart = t  # local t and not account for scr refresh
                txt_coding_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_1, 'tStartRefresh')  # time at next scr refresh
                txt_coding_1.setAutoDraw(True)
            
            # *txt_coding_2* updates
            if txt_coding_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_2.frameNStart = frameN  # exact frame index
                txt_coding_2.tStart = t  # local t and not account for scr refresh
                txt_coding_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_2, 'tStartRefresh')  # time at next scr refresh
                txt_coding_2.setAutoDraw(True)
            
            # *txt_coding_3* updates
            if txt_coding_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_3.frameNStart = frameN  # exact frame index
                txt_coding_3.tStart = t  # local t and not account for scr refresh
                txt_coding_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_3, 'tStartRefresh')  # time at next scr refresh
                txt_coding_3.setAutoDraw(True)
            
            # *txt_coding_4* updates
            if txt_coding_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_4.frameNStart = frameN  # exact frame index
                txt_coding_4.tStart = t  # local t and not account for scr refresh
                txt_coding_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_4, 'tStartRefresh')  # time at next scr refresh
                txt_coding_4.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ISTR_CODINGComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "ISTR_CODING"-------
        for thisComponent in ISTR_CODINGComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # istr_ refers to coding.xlsx 
        flower_key = istr_flower
        storage_key = istr_storage
        happy_key = istr_happy
        neutral_key = istr_neutral
        Training_block_loop.addData('img_istr_coding.started', img_istr_coding.tStartRefresh)
        Training_block_loop.addData('img_istr_coding.stopped', img_istr_coding.tStopRefresh)
        # the Routine "ISTR_CODING" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        Training_trials_loop = data.TrialHandler(nReps=1.0, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('monocular.xlsx'),
            seed=None, name='Training_trials_loop')
        thisExp.addLoop(Training_trials_loop)  # add the loop to the experiment
        thisTraining_trials_loop = Training_trials_loop.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTraining_trials_loop.rgb)
        if thisTraining_trials_loop != None:
            for paramName in thisTraining_trials_loop:
                exec('{} = thisTraining_trials_loop[paramName]'.format(paramName))
        
        for thisTraining_trials_loop in Training_trials_loop:
            currentLoop = Training_trials_loop
            # abbreviate parameter names if possible (e.g. rgb = thisTraining_trials_loop.rgb)
            if thisTraining_trials_loop != None:
                for paramName in thisTraining_trials_loop:
                    exec('{} = thisTraining_trials_loop[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "FIXATION_TRAINING"-------
            continueRoutine = True
            routineTimer.add(0.500000)
            # update component parameters for each repeat
            # keep track of which components have finished
            FIXATION_TRAININGComponents = [img_fixation_training]
            for thisComponent in FIXATION_TRAININGComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            FIXATION_TRAININGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "FIXATION_TRAINING"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = FIXATION_TRAININGClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=FIXATION_TRAININGClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *img_fixation_training* updates
                if img_fixation_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    img_fixation_training.frameNStart = frameN  # exact frame index
                    img_fixation_training.tStart = t  # local t and not account for scr refresh
                    img_fixation_training.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(img_fixation_training, 'tStartRefresh')  # time at next scr refresh
                    img_fixation_training.setAutoDraw(True)
                if img_fixation_training.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > img_fixation_training.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        img_fixation_training.tStop = t  # not accounting for scr refresh
                        img_fixation_training.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(img_fixation_training, 'tStopRefresh')  # time at next scr refresh
                        img_fixation_training.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in FIXATION_TRAININGComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "FIXATION_TRAINING"-------
            for thisComponent in FIXATION_TRAININGComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            Training_trials_loop.addData('img_fixation_training.started', img_fixation_training.tStartRefresh)
            Training_trials_loop.addData('img_fixation_training.stopped', img_fixation_training.tStopRefresh)
            
            # ------Prepare to start Routine "TRIAL_TRAINING"-------
            continueRoutine = True
            # update component parameters for each repeat
            if file_name == 'flower':
                correct = flower_key
            elif file_name == 'storage':
                correct = storage_key
            elif file_name == 'happy':
                correct = happy_key
            elif file_name == 'neutral':
                correct = neutral_key
            img_istr_training.setImage(file_path)
            kb_trial_training.keys = []
            kb_trial_training.rt = []
            _kb_trial_training_allKeys = []
            # keep track of which components have finished
            TRIAL_TRAININGComponents = [img_istr_training, kb_trial_training]
            for thisComponent in TRIAL_TRAININGComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            TRIAL_TRAININGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "TRIAL_TRAINING"-------
            while continueRoutine:
                # get current time
                t = TRIAL_TRAININGClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=TRIAL_TRAININGClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *img_istr_training* updates
                if img_istr_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    img_istr_training.frameNStart = frameN  # exact frame index
                    img_istr_training.tStart = t  # local t and not account for scr refresh
                    img_istr_training.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(img_istr_training, 'tStartRefresh')  # time at next scr refresh
                    img_istr_training.setAutoDraw(True)
                if img_istr_training.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > img_istr_training.tStartRefresh + training_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        img_istr_training.tStop = t  # not accounting for scr refresh
                        img_istr_training.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(img_istr_training, 'tStopRefresh')  # time at next scr refresh
                        img_istr_training.setAutoDraw(False)
                
                # *kb_trial_training* updates
                waitOnFlip = False
                if kb_trial_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    kb_trial_training.frameNStart = frameN  # exact frame index
                    kb_trial_training.tStart = t  # local t and not account for scr refresh
                    kb_trial_training.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(kb_trial_training, 'tStartRefresh')  # time at next scr refresh
                    kb_trial_training.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(kb_trial_training.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(kb_trial_training.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if kb_trial_training.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > kb_trial_training.tStartRefresh + training_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        kb_trial_training.tStop = t  # not accounting for scr refresh
                        kb_trial_training.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(kb_trial_training, 'tStopRefresh')  # time at next scr refresh
                        kb_trial_training.status = FINISHED
                if kb_trial_training.status == STARTED and not waitOnFlip:
                    theseKeys = kb_trial_training.getKeys(keyList=['j','k','l'], waitRelease=False)
                    _kb_trial_training_allKeys.extend(theseKeys)
                    if len(_kb_trial_training_allKeys):
                        kb_trial_training.keys = _kb_trial_training_allKeys[0].name  # just the first key pressed
                        kb_trial_training.rt = _kb_trial_training_allKeys[0].rt
                        # was this correct?
                        if (kb_trial_training.keys == str(correct)) or (kb_trial_training.keys == correct):
                            kb_trial_training.corr = 1
                        else:
                            kb_trial_training.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in TRIAL_TRAININGComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "TRIAL_TRAINING"-------
            for thisComponent in TRIAL_TRAININGComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            Training_trials_loop.addData('img_istr_training.started', img_istr_training.tStartRefresh)
            Training_trials_loop.addData('img_istr_training.stopped', img_istr_training.tStopRefresh)
            # check responses
            if kb_trial_training.keys in ['', [], None]:  # No response was made
                kb_trial_training.keys = None
                # was no response the correct answer?!
                if str(correct).lower() == 'none':
                   kb_trial_training.corr = 1;  # correct non-response
                else:
                   kb_trial_training.corr = 0;  # failed to respond (incorrectly)
            # store data for Training_trials_loop (TrialHandler)
            Training_trials_loop.addData('kb_trial_training.keys',kb_trial_training.keys)
            Training_trials_loop.addData('kb_trial_training.corr', kb_trial_training.corr)
            if kb_trial_training.keys != None:  # we had a response
                Training_trials_loop.addData('kb_trial_training.rt', kb_trial_training.rt)
            Training_trials_loop.addData('kb_trial_training.started', kb_trial_training.tStartRefresh)
            Training_trials_loop.addData('kb_trial_training.stopped', kb_trial_training.tStopRefresh)
            # the Routine "TRIAL_TRAINING" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # ------Prepare to start Routine "FEEDBACK"-------
            continueRoutine = True
            routineTimer.add(1.000000)
            # update component parameters for each repeat
            if kb_trial_training.corr:
                msg = "Corretto! RT={:.3f}".format(kb_trial_training.rt)
                count = count + 1
                print(count)
            else:
                msg = "Oops! Sbagliato"
            txt_feedback.setText(msg)
            # keep track of which components have finished
            FEEDBACKComponents = [txt_feedback]
            for thisComponent in FEEDBACKComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            FEEDBACKClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "FEEDBACK"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = FEEDBACKClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=FEEDBACKClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *txt_feedback* updates
                if txt_feedback.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    txt_feedback.frameNStart = frameN  # exact frame index
                    txt_feedback.tStart = t  # local t and not account for scr refresh
                    txt_feedback.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(txt_feedback, 'tStartRefresh')  # time at next scr refresh
                    txt_feedback.setAutoDraw(True)
                if txt_feedback.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > txt_feedback.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        txt_feedback.tStop = t  # not accounting for scr refresh
                        txt_feedback.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(txt_feedback, 'tStopRefresh')  # time at next scr refresh
                        txt_feedback.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in FEEDBACKComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "FEEDBACK"-------
            for thisComponent in FEEDBACKComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.nextEntry()
            
        # completed 1.0 repeats of 'Training_trials_loop'
        
        
        # ------Prepare to start Routine "BREAK"-------
        continueRoutine = True
        # update component parameters for each repeat
        kb_pausa.keys = []
        kb_pausa.rt = []
        _kb_pausa_allKeys = []
        # keep track of which components have finished
        BREAKComponents = [txt_break, kb_pausa]
        for thisComponent in BREAKComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        BREAKClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "BREAK"-------
        while continueRoutine:
            # get current time
            t = BREAKClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=BREAKClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *txt_break* updates
            if txt_break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_break.frameNStart = frameN  # exact frame index
                txt_break.tStart = t  # local t and not account for scr refresh
                txt_break.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_break, 'tStartRefresh')  # time at next scr refresh
                txt_break.setAutoDraw(True)
            
            # *kb_pausa* updates
            if kb_pausa.status == NOT_STARTED and t >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                kb_pausa.frameNStart = frameN  # exact frame index
                kb_pausa.tStart = t  # local t and not account for scr refresh
                kb_pausa.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(kb_pausa, 'tStartRefresh')  # time at next scr refresh
                kb_pausa.status = STARTED
                # keyboard checking is just starting
                kb_pausa.clock.reset()  # now t=0
                kb_pausa.clearEvents(eventType='keyboard')
            if kb_pausa.status == STARTED:
                theseKeys = kb_pausa.getKeys(keyList=['space'], waitRelease=False)
                _kb_pausa_allKeys.extend(theseKeys)
                if len(_kb_pausa_allKeys):
                    kb_pausa.keys = _kb_pausa_allKeys[-1].name  # just the last key pressed
                    kb_pausa.rt = _kb_pausa_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in BREAKComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "BREAK"-------
        for thisComponent in BREAKComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "BREAK" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'Training_block_loop'
    
    
    # ------Prepare to start Routine "ACCURACY"-------
    continueRoutine = True
    # update component parameters for each repeat
    # compute the % of correct responses during training block
    accuracy = (count/32)*100 #32= 8*4
    acc = "Accuratezza ={:.3f}%".format(accuracy)
    txt_accuracy.setText(acc)
    kb_accuracy.keys = []
    kb_accuracy.rt = []
    _kb_accuracy_allKeys = []
    # keep track of which components have finished
    ACCURACYComponents = [txt_accuracy, kb_accuracy]
    for thisComponent in ACCURACYComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ACCURACYClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ACCURACY"-------
    while continueRoutine:
        # get current time
        t = ACCURACYClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ACCURACYClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *txt_accuracy* updates
        if txt_accuracy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            txt_accuracy.frameNStart = frameN  # exact frame index
            txt_accuracy.tStart = t  # local t and not account for scr refresh
            txt_accuracy.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(txt_accuracy, 'tStartRefresh')  # time at next scr refresh
            txt_accuracy.setAutoDraw(True)
        
        # *kb_accuracy* updates
        waitOnFlip = False
        if kb_accuracy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            kb_accuracy.frameNStart = frameN  # exact frame index
            kb_accuracy.tStart = t  # local t and not account for scr refresh
            kb_accuracy.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(kb_accuracy, 'tStartRefresh')  # time at next scr refresh
            kb_accuracy.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(kb_accuracy.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(kb_accuracy.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if kb_accuracy.status == STARTED and not waitOnFlip:
            theseKeys = kb_accuracy.getKeys(keyList=['space'], waitRelease=False)
            _kb_accuracy_allKeys.extend(theseKeys)
            if len(_kb_accuracy_allKeys):
                kb_accuracy.keys = _kb_accuracy_allKeys[-1].name  # just the last key pressed
                kb_accuracy.rt = _kb_accuracy_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ACCURACYComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ACCURACY"-------
    for thisComponent in ACCURACYComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Training_loop.addData('txt_accuracy.started', txt_accuracy.tStartRefresh)
    Training_loop.addData('txt_accuracy.stopped', txt_accuracy.tStopRefresh)
    # the Routine "ACCURACY" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "EXTRA_TRAINING"-------
    continueRoutine = True
    # update component parameters for each repeat
    kb_extra_training.keys = []
    kb_extra_training.rt = []
    _kb_extra_training_allKeys = []
    # keep track of which components have finished
    EXTRA_TRAININGComponents = [kb_extra_training, txt_extra_training]
    for thisComponent in EXTRA_TRAININGComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    EXTRA_TRAININGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "EXTRA_TRAINING"-------
    while continueRoutine:
        # get current time
        t = EXTRA_TRAININGClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=EXTRA_TRAININGClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # allows to repeat training.
        key = kb_extra_training.keys
        
        if key == 's':
            count = 0
            nb_loop = 0
            nb_loop2 = 0
            continueRoutine = False
            
        
        elif key == 'n':
            Training_loop.finished=True
            continueRoutine = False
            
        
        # *kb_extra_training* updates
        waitOnFlip = False
        if kb_extra_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            kb_extra_training.frameNStart = frameN  # exact frame index
            kb_extra_training.tStart = t  # local t and not account for scr refresh
            kb_extra_training.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(kb_extra_training, 'tStartRefresh')  # time at next scr refresh
            kb_extra_training.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(kb_extra_training.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(kb_extra_training.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if kb_extra_training.status == STARTED and not waitOnFlip:
            theseKeys = kb_extra_training.getKeys(keyList=['s','n'], waitRelease=False)
            _kb_extra_training_allKeys.extend(theseKeys)
            if len(_kb_extra_training_allKeys):
                kb_extra_training.keys = _kb_extra_training_allKeys[-1].name  # just the last key pressed
                kb_extra_training.rt = _kb_extra_training_allKeys[-1].rt
        
        # *txt_extra_training* updates
        if txt_extra_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            txt_extra_training.frameNStart = frameN  # exact frame index
            txt_extra_training.tStart = t  # local t and not account for scr refresh
            txt_extra_training.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(txt_extra_training, 'tStartRefresh')  # time at next scr refresh
            txt_extra_training.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in EXTRA_TRAININGComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "EXTRA_TRAINING"-------
    for thisComponent in EXTRA_TRAININGComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if kb_extra_training.keys in ['', [], None]:  # No response was made
        kb_extra_training.keys = None
    Training_loop.addData('kb_extra_training.keys',kb_extra_training.keys)
    if kb_extra_training.keys != None:  # we had a response
        Training_loop.addData('kb_extra_training.rt', kb_extra_training.rt)
    Training_loop.addData('kb_extra_training.started', kb_extra_training.tStartRefresh)
    Training_loop.addData('kb_extra_training.stopped', kb_extra_training.tStopRefresh)
    # the Routine "EXTRA_TRAINING" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed nreppractice repeats of 'Training_loop'


# ------Prepare to start Routine "ISTR_EXPERIMENT"-------
continueRoutine = True
# update component parameters for each repeat
text_exp_left.setPos((0, 0))
kb_experiment.keys = []
kb_experiment.rt = []
_kb_experiment_allKeys = []
# keep track of which components have finished
ISTR_EXPERIMENTComponents = [text_exp_left, kb_experiment]
for thisComponent in ISTR_EXPERIMENTComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ISTR_EXPERIMENTClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ISTR_EXPERIMENT"-------
while continueRoutine:
    # get current time
    t = ISTR_EXPERIMENTClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ISTR_EXPERIMENTClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_exp_left* updates
    if text_exp_left.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_exp_left.frameNStart = frameN  # exact frame index
        text_exp_left.tStart = t  # local t and not account for scr refresh
        text_exp_left.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_exp_left, 'tStartRefresh')  # time at next scr refresh
        text_exp_left.setAutoDraw(True)
    
    # *kb_experiment* updates
    waitOnFlip = False
    if kb_experiment.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        kb_experiment.frameNStart = frameN  # exact frame index
        kb_experiment.tStart = t  # local t and not account for scr refresh
        kb_experiment.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(kb_experiment, 'tStartRefresh')  # time at next scr refresh
        kb_experiment.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(kb_experiment.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(kb_experiment.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if kb_experiment.status == STARTED and not waitOnFlip:
        theseKeys = kb_experiment.getKeys(keyList=['space'], waitRelease=False)
        _kb_experiment_allKeys.extend(theseKeys)
        if len(_kb_experiment_allKeys):
            kb_experiment.keys = _kb_experiment_allKeys[-1].name  # just the last key pressed
            kb_experiment.rt = _kb_experiment_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ISTR_EXPERIMENTComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ISTR_EXPERIMENT"-------
for thisComponent in ISTR_EXPERIMENTComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "ISTR_EXPERIMENT" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Mimicry_manipulation_loop = data.TrialHandler(nReps=2.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Mimicry_manipulation_loop')
thisExp.addLoop(Mimicry_manipulation_loop)  # add the loop to the experiment
thisMimicry_manipulation_loop = Mimicry_manipulation_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisMimicry_manipulation_loop.rgb)
if thisMimicry_manipulation_loop != None:
    for paramName in thisMimicry_manipulation_loop:
        exec('{} = thisMimicry_manipulation_loop[paramName]'.format(paramName))

for thisMimicry_manipulation_loop in Mimicry_manipulation_loop:
    currentLoop = Mimicry_manipulation_loop
    # abbreviate parameter names if possible (e.g. rgb = thisMimicry_manipulation_loop.rgb)
    if thisMimicry_manipulation_loop != None:
        for paramName in thisMimicry_manipulation_loop:
            exec('{} = thisMimicry_manipulation_loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "ISTR_MIMICRY"-------
    continueRoutine = True
    # update component parameters for each repeat
    txt_mimicry.setText(mimic1)
    kb_mimicry.keys = []
    kb_mimicry.rt = []
    _kb_mimicry_allKeys = []
    img_mimicry.setImage(mimimg)
    # keep track of which components have finished
    ISTR_MIMICRYComponents = [txt_mimicry, kb_mimicry, img_mimicry]
    for thisComponent in ISTR_MIMICRYComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ISTR_MIMICRYClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ISTR_MIMICRY"-------
    while continueRoutine:
        # get current time
        t = ISTR_MIMICRYClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ISTR_MIMICRYClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *txt_mimicry* updates
        if txt_mimicry.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            txt_mimicry.frameNStart = frameN  # exact frame index
            txt_mimicry.tStart = t  # local t and not account for scr refresh
            txt_mimicry.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(txt_mimicry, 'tStartRefresh')  # time at next scr refresh
            txt_mimicry.setAutoDraw(True)
        
        # *kb_mimicry* updates
        waitOnFlip = False
        if kb_mimicry.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            kb_mimicry.frameNStart = frameN  # exact frame index
            kb_mimicry.tStart = t  # local t and not account for scr refresh
            kb_mimicry.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(kb_mimicry, 'tStartRefresh')  # time at next scr refresh
            kb_mimicry.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(kb_mimicry.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(kb_mimicry.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if kb_mimicry.status == STARTED and not waitOnFlip:
            theseKeys = kb_mimicry.getKeys(keyList=['space'], waitRelease=False)
            _kb_mimicry_allKeys.extend(theseKeys)
            if len(_kb_mimicry_allKeys):
                kb_mimicry.keys = _kb_mimicry_allKeys[-1].name  # just the last key pressed
                kb_mimicry.rt = _kb_mimicry_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *img_mimicry* updates
        if img_mimicry.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            img_mimicry.frameNStart = frameN  # exact frame index
            img_mimicry.tStart = t  # local t and not account for scr refresh
            img_mimicry.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(img_mimicry, 'tStartRefresh')  # time at next scr refresh
            img_mimicry.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISTR_MIMICRYComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISTR_MIMICRY"-------
    for thisComponent in ISTR_MIMICRYComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # select counterbalanced manipulation of mimicry
    mimic1 = mimic2
    
    if mimicry == 1:
        mimicry = 0
        mimimg = 'images/istruzioni/mimicry_neutral.png'
    else:
        mimicry = 1
        mimimg = 'images/istruzioni/mimicry_happy.png'
    
        
    Mimicry_manipulation_loop.addData('txt_mimicry.started', txt_mimicry.tStartRefresh)
    Mimicry_manipulation_loop.addData('txt_mimicry.stopped', txt_mimicry.tStopRefresh)
    Mimicry_manipulation_loop.addData('img_mimicry.started', img_mimicry.tStartRefresh)
    Mimicry_manipulation_loop.addData('img_mimicry.stopped', img_mimicry.tStopRefresh)
    # the Routine "ISTR_MIMICRY" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Sperimental_block_loop = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('coding.xlsx'),
        seed=None, name='Sperimental_block_loop')
    thisExp.addLoop(Sperimental_block_loop)  # add the loop to the experiment
    thisSperimental_block_loop = Sperimental_block_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisSperimental_block_loop.rgb)
    if thisSperimental_block_loop != None:
        for paramName in thisSperimental_block_loop:
            exec('{} = thisSperimental_block_loop[paramName]'.format(paramName))
    
    for thisSperimental_block_loop in Sperimental_block_loop:
        currentLoop = Sperimental_block_loop
        # abbreviate parameter names if possible (e.g. rgb = thisSperimental_block_loop.rgb)
        if thisSperimental_block_loop != None:
            for paramName in thisSperimental_block_loop:
                exec('{} = thisSperimental_block_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "ISTR_CODING"-------
        continueRoutine = True
        # update component parameters for each repeat
        kb_istr_coding.keys = []
        kb_istr_coding.rt = []
        _kb_istr_coding_allKeys = []
        img_istr_coding.setImage(Istr_path)
        txt_coding_1.setText(istr_index1)
        txt_coding_2.setText(istr_index2)
        txt_coding_3.setText(istr_index3)
        txt_coding_4.setText(istr_index4)
        # keep track of which components have finished
        ISTR_CODINGComponents = [kb_istr_coding, img_istr_coding, txt_coding_1, txt_coding_2, txt_coding_3, txt_coding_4]
        for thisComponent in ISTR_CODINGComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        ISTR_CODINGClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "ISTR_CODING"-------
        while continueRoutine:
            # get current time
            t = ISTR_CODINGClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=ISTR_CODINGClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *kb_istr_coding* updates
            waitOnFlip = False
            if kb_istr_coding.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                kb_istr_coding.frameNStart = frameN  # exact frame index
                kb_istr_coding.tStart = t  # local t and not account for scr refresh
                kb_istr_coding.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(kb_istr_coding, 'tStartRefresh')  # time at next scr refresh
                kb_istr_coding.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(kb_istr_coding.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(kb_istr_coding.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if kb_istr_coding.status == STARTED and not waitOnFlip:
                theseKeys = kb_istr_coding.getKeys(keyList=['space'], waitRelease=False)
                _kb_istr_coding_allKeys.extend(theseKeys)
                if len(_kb_istr_coding_allKeys):
                    kb_istr_coding.keys = _kb_istr_coding_allKeys[-1].name  # just the last key pressed
                    kb_istr_coding.rt = _kb_istr_coding_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # *img_istr_coding* updates
            if img_istr_coding.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                img_istr_coding.frameNStart = frameN  # exact frame index
                img_istr_coding.tStart = t  # local t and not account for scr refresh
                img_istr_coding.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(img_istr_coding, 'tStartRefresh')  # time at next scr refresh
                img_istr_coding.setAutoDraw(True)
            
            # *txt_coding_1* updates
            if txt_coding_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_1.frameNStart = frameN  # exact frame index
                txt_coding_1.tStart = t  # local t and not account for scr refresh
                txt_coding_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_1, 'tStartRefresh')  # time at next scr refresh
                txt_coding_1.setAutoDraw(True)
            
            # *txt_coding_2* updates
            if txt_coding_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_2.frameNStart = frameN  # exact frame index
                txt_coding_2.tStart = t  # local t and not account for scr refresh
                txt_coding_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_2, 'tStartRefresh')  # time at next scr refresh
                txt_coding_2.setAutoDraw(True)
            
            # *txt_coding_3* updates
            if txt_coding_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_3.frameNStart = frameN  # exact frame index
                txt_coding_3.tStart = t  # local t and not account for scr refresh
                txt_coding_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_3, 'tStartRefresh')  # time at next scr refresh
                txt_coding_3.setAutoDraw(True)
            
            # *txt_coding_4* updates
            if txt_coding_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_coding_4.frameNStart = frameN  # exact frame index
                txt_coding_4.tStart = t  # local t and not account for scr refresh
                txt_coding_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_coding_4, 'tStartRefresh')  # time at next scr refresh
                txt_coding_4.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ISTR_CODINGComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "ISTR_CODING"-------
        for thisComponent in ISTR_CODINGComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # istr_ refers to coding.xlsx 
        flower_key = istr_flower
        storage_key = istr_storage
        happy_key = istr_happy
        neutral_key = istr_neutral
        Sperimental_block_loop.addData('img_istr_coding.started', img_istr_coding.tStartRefresh)
        Sperimental_block_loop.addData('img_istr_coding.stopped', img_istr_coding.tStopRefresh)
        # the Routine "ISTR_CODING" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        Trials_loop = data.TrialHandler(nReps=stim_rep, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('rivalry.xlsx'),
            seed=None, name='Trials_loop')
        thisExp.addLoop(Trials_loop)  # add the loop to the experiment
        thisTrials_loop = Trials_loop.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_loop.rgb)
        if thisTrials_loop != None:
            for paramName in thisTrials_loop:
                exec('{} = thisTrials_loop[paramName]'.format(paramName))
        
        for thisTrials_loop in Trials_loop:
            currentLoop = Trials_loop
            # abbreviate parameter names if possible (e.g. rgb = thisTrials_loop.rgb)
            if thisTrials_loop != None:
                for paramName in thisTrials_loop:
                    exec('{} = thisTrials_loop[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "FIXATION"-------
            continueRoutine = True
            # update component parameters for each repeat
            img_fixation.setPos((0, 0))
            # keep track of which components have finished
            FIXATIONComponents = [img_fixation]
            for thisComponent in FIXATIONComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            FIXATIONClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "FIXATION"-------
            while continueRoutine:
                # get current time
                t = FIXATIONClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=FIXATIONClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *img_fixation* updates
                if img_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    img_fixation.frameNStart = frameN  # exact frame index
                    img_fixation.tStart = t  # local t and not account for scr refresh
                    img_fixation.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(img_fixation, 'tStartRefresh')  # time at next scr refresh
                    img_fixation.setAutoDraw(True)
                if img_fixation.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > img_fixation.tStartRefresh + fixationpoint-frameTolerance:
                        # keep track of stop time/frame for later
                        img_fixation.tStop = t  # not accounting for scr refresh
                        img_fixation.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(img_fixation, 'tStopRefresh')  # time at next scr refresh
                        img_fixation.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in FIXATIONComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "FIXATION"-------
            for thisComponent in FIXATIONComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # the Routine "FIXATION" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # ------Prepare to start Routine "TRIAL"-------
            continueRoutine = True
            # update component parameters for each repeat
            img_trial.setImage(file_path)
            txt_istr1.setText(istr_index1)
            txt_istr2.setText(istr_index2)
            txt_istr3.setText(istr_index3)
            txt_istr4.setText(istr_index4)
            kb_trial.keys = []
            kb_trial.rt = []
            _kb_trial_allKeys = []
            # keep track of which components have finished
            TRIALComponents = [img_trial, txt_istr1, txt_istr2, txt_istr3, txt_istr4, kb_trial]
            for thisComponent in TRIALComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            TRIALClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "TRIAL"-------
            while continueRoutine:
                # get current time
                t = TRIALClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=TRIALClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *img_trial* updates
                if img_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    img_trial.frameNStart = frameN  # exact frame index
                    img_trial.tStart = t  # local t and not account for scr refresh
                    img_trial.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(img_trial, 'tStartRefresh')  # time at next scr refresh
                    img_trial.setAutoDraw(True)
                if img_trial.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > img_trial.tStartRefresh + trial_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        img_trial.tStop = t  # not accounting for scr refresh
                        img_trial.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(img_trial, 'tStopRefresh')  # time at next scr refresh
                        img_trial.setAutoDraw(False)
                
                # *txt_istr1* updates
                if txt_istr1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    txt_istr1.frameNStart = frameN  # exact frame index
                    txt_istr1.tStart = t  # local t and not account for scr refresh
                    txt_istr1.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(txt_istr1, 'tStartRefresh')  # time at next scr refresh
                    txt_istr1.setAutoDraw(True)
                if txt_istr1.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > txt_istr1.tStartRefresh + trial_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        txt_istr1.tStop = t  # not accounting for scr refresh
                        txt_istr1.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(txt_istr1, 'tStopRefresh')  # time at next scr refresh
                        txt_istr1.setAutoDraw(False)
                
                # *txt_istr2* updates
                if txt_istr2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    txt_istr2.frameNStart = frameN  # exact frame index
                    txt_istr2.tStart = t  # local t and not account for scr refresh
                    txt_istr2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(txt_istr2, 'tStartRefresh')  # time at next scr refresh
                    txt_istr2.setAutoDraw(True)
                if txt_istr2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > txt_istr2.tStartRefresh + trial_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        txt_istr2.tStop = t  # not accounting for scr refresh
                        txt_istr2.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(txt_istr2, 'tStopRefresh')  # time at next scr refresh
                        txt_istr2.setAutoDraw(False)
                
                # *txt_istr3* updates
                if txt_istr3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    txt_istr3.frameNStart = frameN  # exact frame index
                    txt_istr3.tStart = t  # local t and not account for scr refresh
                    txt_istr3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(txt_istr3, 'tStartRefresh')  # time at next scr refresh
                    txt_istr3.setAutoDraw(True)
                if txt_istr3.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > txt_istr3.tStartRefresh + trial_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        txt_istr3.tStop = t  # not accounting for scr refresh
                        txt_istr3.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(txt_istr3, 'tStopRefresh')  # time at next scr refresh
                        txt_istr3.setAutoDraw(False)
                
                # *txt_istr4* updates
                if txt_istr4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    txt_istr4.frameNStart = frameN  # exact frame index
                    txt_istr4.tStart = t  # local t and not account for scr refresh
                    txt_istr4.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(txt_istr4, 'tStartRefresh')  # time at next scr refresh
                    txt_istr4.setAutoDraw(True)
                if txt_istr4.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > txt_istr4.tStartRefresh + trial_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        txt_istr4.tStop = t  # not accounting for scr refresh
                        txt_istr4.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(txt_istr4, 'tStopRefresh')  # time at next scr refresh
                        txt_istr4.setAutoDraw(False)
                
                # *kb_trial* updates
                waitOnFlip = False
                if kb_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    kb_trial.frameNStart = frameN  # exact frame index
                    kb_trial.tStart = t  # local t and not account for scr refresh
                    kb_trial.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(kb_trial, 'tStartRefresh')  # time at next scr refresh
                    kb_trial.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(kb_trial.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(kb_trial.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if kb_trial.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > kb_trial.tStartRefresh + trial_duration-frameTolerance:
                        # keep track of stop time/frame for later
                        kb_trial.tStop = t  # not accounting for scr refresh
                        kb_trial.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(kb_trial, 'tStopRefresh')  # time at next scr refresh
                        kb_trial.status = FINISHED
                if kb_trial.status == STARTED and not waitOnFlip:
                    theseKeys = kb_trial.getKeys(keyList=['j','k','l'], waitRelease=False)
                    _kb_trial_allKeys.extend(theseKeys)
                    if len(_kb_trial_allKeys):
                        kb_trial.keys = [key.name for key in _kb_trial_allKeys]  # storing all keys
                        kb_trial.rt = [key.rt for key in _kb_trial_allKeys]
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in TRIALComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "TRIAL"-------
            for thisComponent in TRIALComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            #insert in data log which is the actual mimicry manipulation
            thisExp.addData("mimicry", mimicry)
            Trials_loop.addData('img_trial.started', img_trial.tStartRefresh)
            Trials_loop.addData('img_trial.stopped', img_trial.tStopRefresh)
            # check responses
            if kb_trial.keys in ['', [], None]:  # No response was made
                kb_trial.keys = None
            Trials_loop.addData('kb_trial.keys',kb_trial.keys)
            if kb_trial.keys != None:  # we had a response
                Trials_loop.addData('kb_trial.rt', kb_trial.rt)
            Trials_loop.addData('kb_trial.started', kb_trial.tStartRefresh)
            Trials_loop.addData('kb_trial.stopped', kb_trial.tStopRefresh)
            # the Routine "TRIAL" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # ------Prepare to start Routine "BLACK_SCREEN"-------
            continueRoutine = True
            # update component parameters for each repeat
            # keep track of which components have finished
            BLACK_SCREENComponents = [txt_black_training]
            for thisComponent in BLACK_SCREENComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            BLACK_SCREENClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "BLACK_SCREEN"-------
            while continueRoutine:
                # get current time
                t = BLACK_SCREENClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=BLACK_SCREENClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *txt_black_training* updates
                if txt_black_training.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    txt_black_training.frameNStart = frameN  # exact frame index
                    txt_black_training.tStart = t  # local t and not account for scr refresh
                    txt_black_training.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(txt_black_training, 'tStartRefresh')  # time at next scr refresh
                    txt_black_training.setAutoDraw(True)
                if txt_black_training.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > txt_black_training.tStartRefresh + blackscreen-frameTolerance:
                        # keep track of stop time/frame for later
                        txt_black_training.tStop = t  # not accounting for scr refresh
                        txt_black_training.frameNStop = frameN  # exact frame index
                        win.timeOnFlip(txt_black_training, 'tStopRefresh')  # time at next scr refresh
                        txt_black_training.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in BLACK_SCREENComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "BLACK_SCREEN"-------
            for thisComponent in BLACK_SCREENComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # the Routine "BLACK_SCREEN" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed stim_rep repeats of 'Trials_loop'
        
        
        # ------Prepare to start Routine "BREAK"-------
        continueRoutine = True
        # update component parameters for each repeat
        kb_pausa.keys = []
        kb_pausa.rt = []
        _kb_pausa_allKeys = []
        # keep track of which components have finished
        BREAKComponents = [txt_break, kb_pausa]
        for thisComponent in BREAKComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        BREAKClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "BREAK"-------
        while continueRoutine:
            # get current time
            t = BREAKClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=BREAKClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *txt_break* updates
            if txt_break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_break.frameNStart = frameN  # exact frame index
                txt_break.tStart = t  # local t and not account for scr refresh
                txt_break.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_break, 'tStartRefresh')  # time at next scr refresh
                txt_break.setAutoDraw(True)
            
            # *kb_pausa* updates
            if kb_pausa.status == NOT_STARTED and t >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                kb_pausa.frameNStart = frameN  # exact frame index
                kb_pausa.tStart = t  # local t and not account for scr refresh
                kb_pausa.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(kb_pausa, 'tStartRefresh')  # time at next scr refresh
                kb_pausa.status = STARTED
                # keyboard checking is just starting
                kb_pausa.clock.reset()  # now t=0
                kb_pausa.clearEvents(eventType='keyboard')
            if kb_pausa.status == STARTED:
                theseKeys = kb_pausa.getKeys(keyList=['space'], waitRelease=False)
                _kb_pausa_allKeys.extend(theseKeys)
                if len(_kb_pausa_allKeys):
                    kb_pausa.keys = _kb_pausa_allKeys[-1].name  # just the last key pressed
                    kb_pausa.rt = _kb_pausa_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in BREAKComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "BREAK"-------
        for thisComponent in BREAKComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "BREAK" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'Sperimental_block_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Valuation_block_loop = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Valuation_block_loop')
    thisExp.addLoop(Valuation_block_loop)  # add the loop to the experiment
    thisValuation_block_loop = Valuation_block_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisValuation_block_loop.rgb)
    if thisValuation_block_loop != None:
        for paramName in thisValuation_block_loop:
            exec('{} = thisValuation_block_loop[paramName]'.format(paramName))
    
    for thisValuation_block_loop in Valuation_block_loop:
        currentLoop = Valuation_block_loop
        # abbreviate parameter names if possible (e.g. rgb = thisValuation_block_loop.rgb)
        if thisValuation_block_loop != None:
            for paramName in thisValuation_block_loop:
                exec('{} = thisValuation_block_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "ISTR_VALUATION"-------
        continueRoutine = True
        # update component parameters for each repeat
        txt_istr_valuation.setText(val)
        txt_scale.setText(val2)
        kb_istr_valuation.keys = []
        kb_istr_valuation.rt = []
        _kb_istr_valuation_allKeys = []
        # keep track of which components have finished
        ISTR_VALUATIONComponents = [txt_istr_valuation, txt_scale, kb_istr_valuation]
        for thisComponent in ISTR_VALUATIONComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        ISTR_VALUATIONClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "ISTR_VALUATION"-------
        while continueRoutine:
            # get current time
            t = ISTR_VALUATIONClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=ISTR_VALUATIONClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *txt_istr_valuation* updates
            if txt_istr_valuation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_istr_valuation.frameNStart = frameN  # exact frame index
                txt_istr_valuation.tStart = t  # local t and not account for scr refresh
                txt_istr_valuation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_istr_valuation, 'tStartRefresh')  # time at next scr refresh
                txt_istr_valuation.setAutoDraw(True)
            
            # *txt_scale* updates
            if txt_scale.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                txt_scale.frameNStart = frameN  # exact frame index
                txt_scale.tStart = t  # local t and not account for scr refresh
                txt_scale.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(txt_scale, 'tStartRefresh')  # time at next scr refresh
                txt_scale.setAutoDraw(True)
            
            # *kb_istr_valuation* updates
            waitOnFlip = False
            if kb_istr_valuation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                kb_istr_valuation.frameNStart = frameN  # exact frame index
                kb_istr_valuation.tStart = t  # local t and not account for scr refresh
                kb_istr_valuation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(kb_istr_valuation, 'tStartRefresh')  # time at next scr refresh
                kb_istr_valuation.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(kb_istr_valuation.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(kb_istr_valuation.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if kb_istr_valuation.status == STARTED and not waitOnFlip:
                theseKeys = kb_istr_valuation.getKeys(keyList=['space'], waitRelease=False)
                _kb_istr_valuation_allKeys.extend(theseKeys)
                if len(_kb_istr_valuation_allKeys):
                    kb_istr_valuation.keys = _kb_istr_valuation_allKeys[-1].name  # just the last key pressed
                    kb_istr_valuation.rt = _kb_istr_valuation_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ISTR_VALUATIONComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "ISTR_VALUATION"-------
        for thisComponent in ISTR_VALUATIONComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Valuation_block_loop.addData('txt_istr_valuation.started', txt_istr_valuation.tStartRefresh)
        Valuation_block_loop.addData('txt_istr_valuation.stopped', txt_istr_valuation.tStopRefresh)
        Valuation_block_loop.addData('txt_scale.started', txt_scale.tStartRefresh)
        Valuation_block_loop.addData('txt_scale.stopped', txt_scale.tStopRefresh)
        # check responses
        if kb_istr_valuation.keys in ['', [], None]:  # No response was made
            kb_istr_valuation.keys = None
        Valuation_block_loop.addData('kb_istr_valuation.keys',kb_istr_valuation.keys)
        if kb_istr_valuation.keys != None:  # we had a response
            Valuation_block_loop.addData('kb_istr_valuation.rt', kb_istr_valuation.rt)
        Valuation_block_loop.addData('kb_istr_valuation.started', kb_istr_valuation.tStartRefresh)
        Valuation_block_loop.addData('kb_istr_valuation.stopped', kb_istr_valuation.tStopRefresh)
        # the Routine "ISTR_VALUATION" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        Valuation_loop = data.TrialHandler(nReps=2.0, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('monocular.xlsx'),
            seed=None, name='Valuation_loop')
        thisExp.addLoop(Valuation_loop)  # add the loop to the experiment
        thisValuation_loop = Valuation_loop.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisValuation_loop.rgb)
        if thisValuation_loop != None:
            for paramName in thisValuation_loop:
                exec('{} = thisValuation_loop[paramName]'.format(paramName))
        
        for thisValuation_loop in Valuation_loop:
            currentLoop = Valuation_loop
            # abbreviate parameter names if possible (e.g. rgb = thisValuation_loop.rgb)
            if thisValuation_loop != None:
                for paramName in thisValuation_loop:
                    exec('{} = thisValuation_loop[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "VALUATION"-------
            continueRoutine = True
            # update component parameters for each repeat
            img_valence.setImage(file_path)
            key_valuation.keys = []
            key_valuation.rt = []
            _key_valuation_allKeys = []
            # keep track of which components have finished
            VALUATIONComponents = [img_valence, key_valuation]
            for thisComponent in VALUATIONComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            VALUATIONClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
            frameN = -1
            
            # -------Run Routine "VALUATION"-------
            while continueRoutine:
                # get current time
                t = VALUATIONClock.getTime()
                tThisFlip = win.getFutureFlipTime(clock=VALUATIONClock)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *img_valence* updates
                if img_valence.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    img_valence.frameNStart = frameN  # exact frame index
                    img_valence.tStart = t  # local t and not account for scr refresh
                    img_valence.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(img_valence, 'tStartRefresh')  # time at next scr refresh
                    img_valence.setAutoDraw(True)
                
                # *key_valuation* updates
                waitOnFlip = False
                if key_valuation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_valuation.frameNStart = frameN  # exact frame index
                    key_valuation.tStart = t  # local t and not account for scr refresh
                    key_valuation.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_valuation, 'tStartRefresh')  # time at next scr refresh
                    key_valuation.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_valuation.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_valuation.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_valuation.status == STARTED and not waitOnFlip:
                    theseKeys = key_valuation.getKeys(keyList=['1','2','3','4','5','6','7'], waitRelease=False)
                    _key_valuation_allKeys.extend(theseKeys)
                    if len(_key_valuation_allKeys):
                        key_valuation.keys = _key_valuation_allKeys[-1].name  # just the last key pressed
                        key_valuation.rt = _key_valuation_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in VALUATIONComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "VALUATION"-------
            for thisComponent in VALUATIONComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            Valuation_loop.addData('img_valence.started', img_valence.tStartRefresh)
            Valuation_loop.addData('img_valence.stopped', img_valence.tStopRefresh)
            # check responses
            if key_valuation.keys in ['', [], None]:  # No response was made
                key_valuation.keys = None
            Valuation_loop.addData('key_valuation.keys',key_valuation.keys)
            if key_valuation.keys != None:  # we had a response
                Valuation_loop.addData('key_valuation.rt', key_valuation.rt)
            Valuation_loop.addData('key_valuation.started', key_valuation.tStartRefresh)
            Valuation_loop.addData('key_valuation.stopped', key_valuation.tStopRefresh)
            # the Routine "VALUATION" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed 2.0 repeats of 'Valuation_loop'
        
        
        # ------Prepare to start Routine "SWITCH_COUNTERBALANCE"-------
        continueRoutine = True
        # update component parameters for each repeat
        #switch txt
        
        temp = val
        val = valb
        valb = temp
        
        temp = val2
        val2 = valb2
        valb2 = temp
        
        
        
        # keep track of which components have finished
        SWITCH_COUNTERBALANCEComponents = []
        for thisComponent in SWITCH_COUNTERBALANCEComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        SWITCH_COUNTERBALANCEClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "SWITCH_COUNTERBALANCE"-------
        while continueRoutine:
            # get current time
            t = SWITCH_COUNTERBALANCEClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=SWITCH_COUNTERBALANCEClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in SWITCH_COUNTERBALANCEComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "SWITCH_COUNTERBALANCE"-------
        for thisComponent in SWITCH_COUNTERBALANCEComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "SWITCH_COUNTERBALANCE" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 2.0 repeats of 'Valuation_block_loop'
    
    thisExp.nextEntry()
    
# completed 2.0 repeats of 'Mimicry_manipulation_loop'


# ------Prepare to start Routine "END"-------
continueRoutine = True
# update component parameters for each repeat
kb_end.keys = []
kb_end.rt = []
_kb_end_allKeys = []
# keep track of which components have finished
ENDComponents = [txt_end, kb_end]
for thisComponent in ENDComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ENDClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "END"-------
while continueRoutine:
    # get current time
    t = ENDClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ENDClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *txt_end* updates
    if txt_end.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        txt_end.frameNStart = frameN  # exact frame index
        txt_end.tStart = t  # local t and not account for scr refresh
        txt_end.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(txt_end, 'tStartRefresh')  # time at next scr refresh
        txt_end.setAutoDraw(True)
    
    # *kb_end* updates
    waitOnFlip = False
    if kb_end.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        kb_end.frameNStart = frameN  # exact frame index
        kb_end.tStart = t  # local t and not account for scr refresh
        kb_end.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(kb_end, 'tStartRefresh')  # time at next scr refresh
        kb_end.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(kb_end.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(kb_end.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if kb_end.status == STARTED and not waitOnFlip:
        theseKeys = kb_end.getKeys(keyList=['space'], waitRelease=False)
        _kb_end_allKeys.extend(theseKeys)
        if len(_kb_end_allKeys):
            kb_end.keys = _kb_end_allKeys[-1].name  # just the last key pressed
            kb_end.rt = _kb_end_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ENDComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "END"-------
for thisComponent in ENDComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "END" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='semicolon')
thisExp.saveAsPickle(filename)
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
