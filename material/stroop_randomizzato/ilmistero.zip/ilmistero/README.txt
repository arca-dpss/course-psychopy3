 Experiment:     	ILMISTERO 1.0
============================================================
 Programmer:     	Thomas Quettier
============================================================
 Date:           	18/04/2023
============================================================
 Description:    	Non mi ricordo che fa
============================================================

ATTENZIONE
------------------------

L'esperimento non funziona:
- il nome del file data log manda in crash l'esperimento
- non so quanti blocchi ci sono
- il trial deve durare 60 sec
- la fissazione deve durare 2 sec
- il black screen deve durare 3 sec





Version updating:
------------------------
