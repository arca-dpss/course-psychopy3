# README — Stroop Task Script (PsychoPy)

Questo script (`stroop.py`) definisce la logica di gestione dei **blocchi linguistici** (ITA/ENG) e del **blocco di pratica** per un esperimento Stroop in PsychoPy.

---

## ⚙️ Struttura generale

Lo script imposta i parametri dei loop principali prima dell’inizio dell’esperimento, basandosi sui valori contenuti in `expInfo` (raccolti nella finestra iniziale di PsychoPy).

### Parametri principali
- **n_rep**: numero di ripetizioni per ogni blocco (default = 5)  
- **rep_ita**: flag per il blocco in italiano (1 = esegui, 0 = salta)  
- **rep_eng**: flag per il blocco in inglese (1 = esegui, 0 = salta)  
- **rep_practice**: flag per il blocco di pratica (1 = esegui, 0 = salta)

---

## 🔄 Logica di esecuzione

### 1. Ordine dei blocchi linguistici
L’ordine di presentazione dipende dal **numero del partecipante** (`expInfo['participant']`):

- Se il numero è **pari** → ordine: **ITA → ENG**
- Se il numero è **dispari** → ordine: **ENG → ITA**

Il valore dell’ordine viene salvato nel file dei dati (`thisExp.addData("ordine", ...)`) per tracciabilità.

### 2. Gestione del blocco pratica
La variabile `expInfo['practice']` controlla se includere il blocco di pratica:

- `1` → il blocco pratica viene **eseguito**
- `0` → il blocco pratica viene **saltato**

---

## 🧠 Esempio di uso

Durante l’inizio dell’esperimento, nella finestra di dialogo di PsychoPy, assicurarsi di includere i seguenti campi in `expInfo`:

```python
expInfo = {
    'participant': '',  # Numero identificativo del partecipante
    'practice': '1'     # 1 = con pratica, 0 = senza pratica
}