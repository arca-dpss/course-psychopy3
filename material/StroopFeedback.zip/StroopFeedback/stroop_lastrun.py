﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2025.1.1),
    on Thu Oct 30 12:01:14 2025
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2025.1.1'
expName = 'stroop'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'gender (m/f)': 'f',
    'age': '',
    'participant': 'inserire numero',
    'practice': '1',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1512, 982]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data' + os.sep + '%s_%s' %(expInfo['participant'], expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/thomasquettier/Desktop/ARCAPY/StroopFeedback/stroop_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('debug')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='norm',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'norm'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    if deviceManager.getDevice('istr_ita_kb') is None:
        # initialise istr_ita_kb
        istr_ita_kb = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='istr_ita_kb',
        )
    if deviceManager.getDevice('trial_ita_kb') is None:
        # initialise trial_ita_kb
        trial_ita_kb = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='trial_ita_kb',
        )
    if deviceManager.getDevice('thank_kb') is None:
        # initialise thank_kb
        thank_kb = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='thank_kb',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "SETTING" ---
    # Run 'Begin Experiment' code from setting_code
    # ============================
    # PARAMETRI PER I LOOP
    # ============================
    
    # Numero di ripetizioni per ogni blocco
    n_rep = 500
    
    # Estrae il numero del partecipante dal dizionario expInfo
    # (serve per decidere l'ordine di presentazione dei blocchi)
    num = int(expInfo['participant'])
    
    # Se il numero del partecipante è pari → inizia con ITA, poi ENG
    # Se è dispari → inizia con ENG, poi ITA
    if (num % 2) == 0:
        rep_ita = 1   # attiva blocco in italiano
        rep_eng = 0   # disattiva blocco in inglese
        thisExp.addData("ordine", "ITA-ENG")  # salva l’ordine nel file dei dati
    else:
        rep_ita = 0
        rep_eng = 1
        thisExp.addData("ordine", "ENG-ITA")
    
    # ============================
    # GESTIONE BLOCCO PRATICA
    # ============================
    
    # Legge dal dizionario expInfo se il partecipante deve fare la pratica (1 = sì, 0 = no)
    practice = int(expInfo['practice'])
    
    # Se practice = 1 → include il blocco di pratica
    # Se practice = 0 → salta il blocco di pratica
    if practice == 1:
        rep_practice = 1   # esegue il blocco di pratica
    else:
        rep_practice = 0   # salta il blocco di pratica
    
    # --- Initialize components for Routine "INST_ITA" ---
    istr_ita_kb = keyboard.Keyboard(deviceName='istr_ita_kb')
    istr_ita_txt = visual.TextStim(win=win, name='istr_ita_txt',
        text='Ricorda, ignora la parola stessa; premi: \nSinistra per lettere rosse \nGiù per lettere verdi \nDestra per lettere blu \n\nPremi qualsiasi tasto per continuare',
        font='Arial',
        pos=[0, 0], draggable=False, height=0.1, wrapWidth=None, ori=0, 
        color=[1, 1, 1], colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "TRIAL_ITA" ---
    trial_ita_txt = visual.TextStim(win=win, name='trial_ita_txt',
        text='',
        font='Arial',
        pos=[0, 0], draggable=False, height=0.2, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-1.0);
    trial_ita_kb = keyboard.Keyboard(deviceName='trial_ita_kb')
    
    # --- Initialize components for Routine "FEEDBACK" ---
    # Run 'Begin Experiment' code from feedback_code
    total_correct = 0
    feedback_txt = visual.TextStim(win=win, name='feedback_txt',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.1, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "THANKS" ---
    thanks_txt = visual.TextStim(win=win, name='thanks_txt',
        text='Grazie per la partecipazione.',
        font='arial',
        pos=[0, 0], draggable=False, height=0.3, wrapWidth=None, ori=0, 
        color=[1, 1, 1], colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    thank_kb = keyboard.Keyboard(deviceName='thank_kb')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "SETTING" ---
    # create an object to store info about Routine SETTING
    SETTING = data.Routine(
        name='SETTING',
        components=[],
    )
    SETTING.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for SETTING
    SETTING.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    SETTING.tStart = globalClock.getTime(format='float')
    SETTING.status = STARTED
    thisExp.addData('SETTING.started', SETTING.tStart)
    SETTING.maxDuration = None
    # keep track of which components have finished
    SETTINGComponents = SETTING.components
    for thisComponent in SETTING.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "SETTING" ---
    SETTING.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=SETTING,
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            SETTING.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in SETTING.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "SETTING" ---
    for thisComponent in SETTING.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for SETTING
    SETTING.tStop = globalClock.getTime(format='float')
    SETTING.tStopRefresh = tThisFlipGlobal
    thisExp.addData('SETTING.stopped', SETTING.tStop)
    thisExp.nextEntry()
    # the Routine "SETTING" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Loop_practice = data.TrialHandler2(
        name='Loop_practice',
        nReps=rep_practice, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=[None], 
        seed=None, 
    )
    thisExp.addLoop(Loop_practice)  # add the loop to the experiment
    thisLoop_practice = Loop_practice.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_practice.rgb)
    if thisLoop_practice != None:
        for paramName in thisLoop_practice:
            globals()[paramName] = thisLoop_practice[paramName]
    
    for thisLoop_practice in Loop_practice:
        Loop_practice.status = STARTED
        if hasattr(thisLoop_practice, 'status'):
            thisLoop_practice.status = STARTED
        currentLoop = Loop_practice
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # abbreviate parameter names if possible (e.g. rgb = thisLoop_practice.rgb)
        if thisLoop_practice != None:
            for paramName in thisLoop_practice:
                globals()[paramName] = thisLoop_practice[paramName]
        
        # --- Prepare to start Routine "INST_ITA" ---
        # create an object to store info about Routine INST_ITA
        INST_ITA = data.Routine(
            name='INST_ITA',
            components=[istr_ita_kb, istr_ita_txt],
        )
        INST_ITA.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # create starting attributes for istr_ita_kb
        istr_ita_kb.keys = []
        istr_ita_kb.rt = []
        _istr_ita_kb_allKeys = []
        # store start times for INST_ITA
        INST_ITA.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        INST_ITA.tStart = globalClock.getTime(format='float')
        INST_ITA.status = STARTED
        thisExp.addData('INST_ITA.started', INST_ITA.tStart)
        INST_ITA.maxDuration = None
        # keep track of which components have finished
        INST_ITAComponents = INST_ITA.components
        for thisComponent in INST_ITA.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "INST_ITA" ---
        INST_ITA.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisLoop_practice, 'status') and thisLoop_practice.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *istr_ita_kb* updates
            waitOnFlip = False
            
            # if istr_ita_kb is starting this frame...
            if istr_ita_kb.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                istr_ita_kb.frameNStart = frameN  # exact frame index
                istr_ita_kb.tStart = t  # local t and not account for scr refresh
                istr_ita_kb.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(istr_ita_kb, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'istr_ita_kb.started')
                # update status
                istr_ita_kb.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(istr_ita_kb.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(istr_ita_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if istr_ita_kb.status == STARTED and not waitOnFlip:
                theseKeys = istr_ita_kb.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
                _istr_ita_kb_allKeys.extend(theseKeys)
                if len(_istr_ita_kb_allKeys):
                    istr_ita_kb.keys = _istr_ita_kb_allKeys[-1].name  # just the last key pressed
                    istr_ita_kb.rt = _istr_ita_kb_allKeys[-1].rt
                    istr_ita_kb.duration = _istr_ita_kb_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *istr_ita_txt* updates
            
            # if istr_ita_txt is starting this frame...
            if istr_ita_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                istr_ita_txt.frameNStart = frameN  # exact frame index
                istr_ita_txt.tStart = t  # local t and not account for scr refresh
                istr_ita_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(istr_ita_txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'istr_ita_txt.started')
                # update status
                istr_ita_txt.status = STARTED
                istr_ita_txt.setAutoDraw(True)
            
            # if istr_ita_txt is active this frame...
            if istr_ita_txt.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=INST_ITA,
                )
                # skip the frame we paused on
                continue
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                INST_ITA.forceEnded = routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in INST_ITA.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "INST_ITA" ---
        for thisComponent in INST_ITA.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for INST_ITA
        INST_ITA.tStop = globalClock.getTime(format='float')
        INST_ITA.tStopRefresh = tThisFlipGlobal
        thisExp.addData('INST_ITA.stopped', INST_ITA.tStop)
        # the Routine "INST_ITA" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        Loop_training = data.TrialHandler2(
            name='Loop_training',
            nReps=n_rep, 
            method='random', 
            extraInfo=expInfo, 
            originPath=-1, 
            trialList=data.importConditions('conditions.xlsx'), 
            seed=None, 
        )
        thisExp.addLoop(Loop_training)  # add the loop to the experiment
        thisLoop_training = Loop_training.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisLoop_training.rgb)
        if thisLoop_training != None:
            for paramName in thisLoop_training:
                globals()[paramName] = thisLoop_training[paramName]
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        
        for thisLoop_training in Loop_training:
            Loop_training.status = STARTED
            if hasattr(thisLoop_training, 'status'):
                thisLoop_training.status = STARTED
            currentLoop = Loop_training
            thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            # abbreviate parameter names if possible (e.g. rgb = thisLoop_training.rgb)
            if thisLoop_training != None:
                for paramName in thisLoop_training:
                    globals()[paramName] = thisLoop_training[paramName]
            
            # --- Prepare to start Routine "TRIAL_ITA" ---
            # create an object to store info about Routine TRIAL_ITA
            TRIAL_ITA = data.Routine(
                name='TRIAL_ITA',
                components=[trial_ita_txt, trial_ita_kb],
            )
            TRIAL_ITA.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            trial_ita_txt.setColor(letterColor, colorSpace='rgb')
            # create starting attributes for trial_ita_kb
            trial_ita_kb.keys = []
            trial_ita_kb.rt = []
            _trial_ita_kb_allKeys = []
            # store start times for TRIAL_ITA
            TRIAL_ITA.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            TRIAL_ITA.tStart = globalClock.getTime(format='float')
            TRIAL_ITA.status = STARTED
            thisExp.addData('TRIAL_ITA.started', TRIAL_ITA.tStart)
            TRIAL_ITA.maxDuration = None
            # keep track of which components have finished
            TRIAL_ITAComponents = TRIAL_ITA.components
            for thisComponent in TRIAL_ITA.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "TRIAL_ITA" ---
            TRIAL_ITA.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine:
                # if trial has changed, end Routine now
                if hasattr(thisLoop_training, 'status') and thisLoop_training.status == STOPPING:
                    continueRoutine = False
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *trial_ita_txt* updates
                
                # if trial_ita_txt is starting this frame...
                if trial_ita_txt.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    trial_ita_txt.frameNStart = frameN  # exact frame index
                    trial_ita_txt.tStart = t  # local t and not account for scr refresh
                    trial_ita_txt.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(trial_ita_txt, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'trial_ita_txt.started')
                    # update status
                    trial_ita_txt.status = STARTED
                    trial_ita_txt.setAutoDraw(True)
                
                # if trial_ita_txt is active this frame...
                if trial_ita_txt.status == STARTED:
                    # update params
                    trial_ita_txt.setText(parola, log=False)
                
                # *trial_ita_kb* updates
                waitOnFlip = False
                
                # if trial_ita_kb is starting this frame...
                if trial_ita_kb.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                    # keep track of start time/frame for later
                    trial_ita_kb.frameNStart = frameN  # exact frame index
                    trial_ita_kb.tStart = t  # local t and not account for scr refresh
                    trial_ita_kb.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(trial_ita_kb, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'trial_ita_kb.started')
                    # update status
                    trial_ita_kb.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(trial_ita_kb.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(trial_ita_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if trial_ita_kb.status == STARTED and not waitOnFlip:
                    theseKeys = trial_ita_kb.getKeys(keyList=["left","down","right"], ignoreKeys=["escape"], waitRelease=False)
                    _trial_ita_kb_allKeys.extend(theseKeys)
                    if len(_trial_ita_kb_allKeys):
                        trial_ita_kb.keys = _trial_ita_kb_allKeys[-1].name  # just the last key pressed
                        trial_ita_kb.rt = _trial_ita_kb_allKeys[-1].rt
                        trial_ita_kb.duration = _trial_ita_kb_allKeys[-1].duration
                        # was this correct?
                        if (trial_ita_kb.keys == str(corrAns)) or (trial_ita_kb.keys == corrAns):
                            trial_ita_kb.corr = 1
                        else:
                            trial_ita_kb.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer, globalClock], 
                        currentRoutine=TRIAL_ITA,
                    )
                    # skip the frame we paused on
                    continue
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    TRIAL_ITA.forceEnded = routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in TRIAL_ITA.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "TRIAL_ITA" ---
            for thisComponent in TRIAL_ITA.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for TRIAL_ITA
            TRIAL_ITA.tStop = globalClock.getTime(format='float')
            TRIAL_ITA.tStopRefresh = tThisFlipGlobal
            thisExp.addData('TRIAL_ITA.stopped', TRIAL_ITA.tStop)
            # Run 'End Routine' code from trial_ita_code
            thisExp.addData("blocco", "ITA")
            # check responses
            if trial_ita_kb.keys in ['', [], None]:  # No response was made
                trial_ita_kb.keys = None
                # was no response the correct answer?!
                if str(corrAns).lower() == 'none':
                   trial_ita_kb.corr = 1;  # correct non-response
                else:
                   trial_ita_kb.corr = 0;  # failed to respond (incorrectly)
            # store data for Loop_training (TrialHandler)
            Loop_training.addData('trial_ita_kb.keys',trial_ita_kb.keys)
            Loop_training.addData('trial_ita_kb.corr', trial_ita_kb.corr)
            if trial_ita_kb.keys != None:  # we had a response
                Loop_training.addData('trial_ita_kb.rt', trial_ita_kb.rt)
                Loop_training.addData('trial_ita_kb.duration', trial_ita_kb.duration)
            # the Routine "TRIAL_ITA" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "FEEDBACK" ---
            # create an object to store info about Routine FEEDBACK
            FEEDBACK = data.Routine(
                name='FEEDBACK',
                components=[feedback_txt],
            )
            FEEDBACK.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # Run 'Begin Routine' code from feedback_code
            # Add current trial correctness to counter
            # trial_ita_kb.corr is 1 (correct) or 0 (incorrect)
            total_correct += trial_ita_kb.corr
            
            # If at least 2 correct, end practice loop
            if total_correct >= 2:
                Loop_training.finished = True
            
            
            # creare il feedback per la variabile "feedback"
            
            if trial_ita_kb.corr == 1:
                feedback = "Ottimo ! RT = %.3f" % trial_ita_kb.rt 
            else:
                feedback = "Oops"
                
               
            feedback_txt.setText(feedback)
            # store start times for FEEDBACK
            FEEDBACK.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            FEEDBACK.tStart = globalClock.getTime(format='float')
            FEEDBACK.status = STARTED
            thisExp.addData('FEEDBACK.started', FEEDBACK.tStart)
            FEEDBACK.maxDuration = None
            # keep track of which components have finished
            FEEDBACKComponents = FEEDBACK.components
            for thisComponent in FEEDBACK.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "FEEDBACK" ---
            FEEDBACK.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 0.3:
                # if trial has changed, end Routine now
                if hasattr(thisLoop_training, 'status') and thisLoop_training.status == STOPPING:
                    continueRoutine = False
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *feedback_txt* updates
                
                # if feedback_txt is starting this frame...
                if feedback_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    feedback_txt.frameNStart = frameN  # exact frame index
                    feedback_txt.tStart = t  # local t and not account for scr refresh
                    feedback_txt.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(feedback_txt, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'feedback_txt.started')
                    # update status
                    feedback_txt.status = STARTED
                    feedback_txt.setAutoDraw(True)
                
                # if feedback_txt is active this frame...
                if feedback_txt.status == STARTED:
                    # update params
                    pass
                
                # if feedback_txt is stopping this frame...
                if feedback_txt.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > feedback_txt.tStartRefresh + 0.3-frameTolerance:
                        # keep track of stop time/frame for later
                        feedback_txt.tStop = t  # not accounting for scr refresh
                        feedback_txt.tStopRefresh = tThisFlipGlobal  # on global time
                        feedback_txt.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'feedback_txt.stopped')
                        # update status
                        feedback_txt.status = FINISHED
                        feedback_txt.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer, globalClock], 
                        currentRoutine=FEEDBACK,
                    )
                    # skip the frame we paused on
                    continue
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    FEEDBACK.forceEnded = routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in FEEDBACK.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "FEEDBACK" ---
            for thisComponent in FEEDBACK.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for FEEDBACK
            FEEDBACK.tStop = globalClock.getTime(format='float')
            FEEDBACK.tStopRefresh = tThisFlipGlobal
            thisExp.addData('FEEDBACK.stopped', FEEDBACK.tStop)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if FEEDBACK.maxDurationReached:
                routineTimer.addTime(-FEEDBACK.maxDuration)
            elif FEEDBACK.forceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-0.300000)
            # mark thisLoop_training as finished
            if hasattr(thisLoop_training, 'status'):
                thisLoop_training.status = FINISHED
            # if awaiting a pause, pause now
            if Loop_training.status == PAUSED:
                thisExp.status = PAUSED
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[globalClock], 
                )
                # once done pausing, restore running status
                Loop_training.status = STARTED
            thisExp.nextEntry()
            
        # completed n_rep repeats of 'Loop_training'
        Loop_training.status = FINISHED
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # mark thisLoop_practice as finished
        if hasattr(thisLoop_practice, 'status'):
            thisLoop_practice.status = FINISHED
        # if awaiting a pause, pause now
        if Loop_practice.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            Loop_practice.status = STARTED
    # completed rep_practice repeats of 'Loop_practice'
    Loop_practice.status = FINISHED
    
    
    # --- Prepare to start Routine "THANKS" ---
    # create an object to store info about Routine THANKS
    THANKS = data.Routine(
        name='THANKS',
        components=[thanks_txt, thank_kb],
    )
    THANKS.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for thank_kb
    thank_kb.keys = []
    thank_kb.rt = []
    _thank_kb_allKeys = []
    # store start times for THANKS
    THANKS.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    THANKS.tStart = globalClock.getTime(format='float')
    THANKS.status = STARTED
    thisExp.addData('THANKS.started', THANKS.tStart)
    THANKS.maxDuration = None
    # keep track of which components have finished
    THANKSComponents = THANKS.components
    for thisComponent in THANKS.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "THANKS" ---
    THANKS.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *thanks_txt* updates
        
        # if thanks_txt is starting this frame...
        if thanks_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            thanks_txt.frameNStart = frameN  # exact frame index
            thanks_txt.tStart = t  # local t and not account for scr refresh
            thanks_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(thanks_txt, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'thanks_txt.started')
            # update status
            thanks_txt.status = STARTED
            thanks_txt.setAutoDraw(True)
        
        # if thanks_txt is active this frame...
        if thanks_txt.status == STARTED:
            # update params
            pass
        
        # *thank_kb* updates
        waitOnFlip = False
        
        # if thank_kb is starting this frame...
        if thank_kb.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            thank_kb.frameNStart = frameN  # exact frame index
            thank_kb.tStart = t  # local t and not account for scr refresh
            thank_kb.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(thank_kb, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'thank_kb.started')
            # update status
            thank_kb.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(thank_kb.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(thank_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if thank_kb.status == STARTED and not waitOnFlip:
            theseKeys = thank_kb.getKeys(keyList=['q'], ignoreKeys=["escape"], waitRelease=False)
            _thank_kb_allKeys.extend(theseKeys)
            if len(_thank_kb_allKeys):
                thank_kb.keys = _thank_kb_allKeys[-1].name  # just the last key pressed
                thank_kb.rt = _thank_kb_allKeys[-1].rt
                thank_kb.duration = _thank_kb_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=THANKS,
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            THANKS.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in THANKS.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "THANKS" ---
    for thisComponent in THANKS.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for THANKS
    THANKS.tStop = globalClock.getTime(format='float')
    THANKS.tStopRefresh = tThisFlipGlobal
    thisExp.addData('THANKS.stopped', THANKS.tStop)
    # check responses
    if thank_kb.keys in ['', [], None]:  # No response was made
        thank_kb.keys = None
    thisExp.addData('thank_kb.keys',thank_kb.keys)
    if thank_kb.keys != None:  # we had a response
        thisExp.addData('thank_kb.rt', thank_kb.rt)
        thisExp.addData('thank_kb.duration', thank_kb.duration)
    thisExp.nextEntry()
    # the Routine "THANKS" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
