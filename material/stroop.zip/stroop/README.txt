 Experiment:     	STROOP valutazione ARCA
============================================================
 Programmer:     	Metti qui il tuo nome
============================================================
 Date:           	08/11/2024
============================================================
 Description:    	Test per la valutazione del corso ARCA
============================================================

Compito
------------------------

- Ricostruire un esperimento Stroop
- Certi componenti sono disponibili nella lista componenti
- Bisogna ricreare tutti loops

Condizioni Openbage/certificato:
------------------------

Superamento della prova finale con un punteggio di almeno il 75% (15 punti) del totale (20 punti). La prova finale consiste nella creazione di un esperimento di psicologia comportamentale utilizzando Psychopy3. Nello specifico, in una versione controbilanciata automaticamente dell'esperimento di Stroop in cui un feedback è fornito dopo un certo numero di risposte corrette. La prova ha una durata di 90 minuti. 

La valutazione avviene secondo il seguente criterio:
- 9  per la creazione di una versione dello stroop funzionante in qualsiasi lingua
- 3 punti per l’implementazione di un controbilanciamento tra due lingue
- 3 punti per la creazione di una routine che permette di scegliere di rifare la pratica
- 3 punti per la presenza di un feedback durante la pratica
- 2 punti per la chiarezza e la metodologia (nomi routine, nomi componenti, commenti su "incode")



Valutazione
------------------------
- Vai il più avanti possibile. 
- Quando non arrivi ad andare avanti chiama l'istruttore
- Quando funziona creare una cartella nome.cognome e conservare l'esperimento (chiedimi la chiavetta usb perche devo ricuperare il tuo esperimento)

