Experiment:     	STROOP valutazione ARCA
============================================================
 Programmer:     	Metti qui il tuo nome
============================================================
 Date:           	[Inserisci la data dell'esame]
============================================================
 Description:    	Test per la valutazione del corso ARCA - Psychopy3 Builder
============================================================

INFORMAZIONI GENERALI
------------------------

Punteggio totale:          26 punti
Soglia di superamento:     19 punti (75%)
Open Badge:                Conseguito se punteggio >= 19
Durata esame:              90 minuti


TASK OBBLIGATORI (6 punti - Base minima)
------------------------

[✓] TASK 1: BLOCCO SPERIMENTALE STROOP FUNZIONANTE (6 punti)
    Creare un blocco sperimentale dello Stroop che funziona in QUALSIASI lingua
    - Minimo 10 trial con colori incongruenti
    - Registrare risposte e tempi di reazione
    - Compito INTERAMENTE FUNZIONANTE (no crash)
    
    Checklist:
    ☐ Loop sperimentale creato
    ☐ Stimoli generati (testo colorato)
    ☐ Risposte registrate
    ☐ File dati salvati
    ☐ No crash o errori critici


SUBTOTALE OBBLIGATORI: 6 punti


TASK CONSIGLIATI (20 punti - Altamente consigliati per superare)
------------------------

[] TASK 2: CODICE ORDINATO E COMMENTATO (2 punti)
    Componenti ROUTINE organizzate e nominate chiaramente
    - Loop denominati in modo logico
    - Almeno 5 commenti in-code nelle sezioni principali
    - Nessun componente "orphano"
    
    Checklist:
    ☐ Nomi componenti chiari e coerenti
    ☐ Loop organizzati gerarchicamente
    ☐ Commenti presenti nelle routine critiche
    ☐ Codice Python con indentazione corretta


[] TASK 3: CAPACITÀ DI DEBUGGING DIMOSTRABILE (2 punti)
    Dimostrare capacità di leggere messaggi di errore e risolvere problemi
    - Se si trovano bug durante l'esecuzione, tentare di risolverli
    - Se si chiedono aiuti, specificare il messaggio di errore esatto
    - Massimo 1 richiesta di aiuto di debug
    
    Checklist:
    ☐ Studente ha tentato risolvere problemi autonomamente
    ☐ Ha provato a leggere i messaggi di errore
    ☐ Ha fatto domande specifiche (con codice/errore)


[] TASK 4: NUMERO TRIAL CONFIGURABILE (EasyCode) (2 punti)
    Permettere di variare il numero di trial all'inizio dell'esperimento
    - Creare una Routine 'Settings' all'inizio del flow
    - Chiedere allo studente: "Quanti trial? (5/10/20)"
    - Usare una variabile (es: num_trials) nel loop
    
    Checklist:
    ☐ Routine 'Settings' creata all'inizio
    ☐ Dialogue Box che chiede numero trial
    ☐ Variabile num_trials registrata
    ☐ Loop condizionato a num_trials (nReps = $num_trials)


[] TASK 5: DIALOGUE BOX OTTIMIZZATA (2 punti)
    Dialogue Box all'inizio che raccoglie:
    1. Nome dello sperimentatore
    2. Variabili di controllo (es: modalità easy/hard)
    - Usare dict per rendere il codice pulito e riutilizzabile
    
    Checklist:
    ☐ Dialogue Box con almeno 2 campi (name, control_var)
    ☐ Variabili salvate correttamente nei dati
    ☐ Struttura con dict/list ordinata
    ☐ Feedback visibile (es: 'Ciao, [nome]!')


[] TASK 6: README DELLA VERSIONE STROOP (2 punti)
    Creare un file README.md che spiega:
    - Cosa fa questo Stroop
    - Istruzioni per lo studente
    - Descrizione dei componenti principali
    - Come i dati vengono salvati
    - Limitazioni / note tecniche
    
    Checklist:
    ☐ File README.md creato
    ☐ Descrizione dell'esperimento
    ☐ Istruzioni per l'utente
    ☐ Spiegazione componenti (routine, loop, variabili)
    ☐ Descrizione file output


[] TASK 7: BLOCCO TRAINING CON FEEDBACK (2 punti)
    Aggiungere un blocco di pratica PRIMA dello Stroop principale
    - Minimo 5 trial di training
    - FEEDBACK dopo ogni risposta ("Corretto! ✓" o "Sbagliato ✗")
    - Feedback visibile per almeno 1 secondo
    
    Checklist:
    ☐ Loop training separato dal loop principale
    ☐ Feedback visibile dopo ogni risposta
    ☐ Feedback scompare prima del trial successivo


[] TASK 8: POSSIBILITÀ DI SALTARE IL TRAINING (2 punti)
    All'inizio: chiedere "Vuoi fare il training? (s/n)"
    - Se SÌ: esegui il training
    - Se NO: salta direttamente allo Stroop principale
    - Usare Dialogue Box e variabile booleana
    
    Checklist:
    ☐ Dialogue Box funzionante all'inizio
    ☐ Risposta registrata in una variabile
    ☐ Loop training con nReps = 0 oppure nReps = 1


[] TASK 9: STROOP BILINGUE (DUE LINGUE) (2 punti)
    Stroop funzionante in ITALIANO E INGLESE
    - I nomi dei colori cambiano in base alla lingua
    - Minimo 10 trial per lingua (totale 20 trial)
    - Dati registrano quale lingua è stata usata
    
    Checklist:
    ☐ Due lingue implementate
    ☐ Nomi colori cambiano correttamente
    ☐ Dati registrano quale lingua è stata usata


[] TASK 10: SELEZIONE DELLA LINGUA (2 punti)
    Permettere di SCEGLIERE la lingua all'inizio
    - Opzione A: Dialogue Box (Input: "it/en")
    - Opzione B: Immagini cliccabili (Bandiera italiana vs UK)
    - Una sola lingua viene eseguita
    
    Checklist:
    ☐ Selezione lingua funzionante
    ☐ Solo una lingua eseguita
    ☐ Scelta registrata nei dati


[] TASK 11: STROOP BILINGUE CONTROBILANCIATO (2 punti)
    Creare una versione in cui la lingua cambia TRA studenti diversi
    - Primo studente: ITALIANO primo, poi INGLESE
    - Secondo studente: INGLESE primo, poi ITALIANO
    - Almeno 10 trial per lingua (totale 20 trial)
    
    Checklist:
    ☐ Due lingue eseguite in ordine casuale
    ☐ Almeno 10 trial per lingua
    ☐ Ordine registrato nel file dati (es: 'order = en_it')


SUBTOTALE CONSIGLIATI: 20 punti


DISTRIBUZIONE PUNTI TOTALE
------------------------

OBBLIGATORI (Task 1):         6 punti
CONSIGLIATI (Task 2-11):     20 punti
                             ─────────
PUNTEGGIO TOTALE POSSIBILE:   26 punti
SOGLIA DI SUPERAMENTO:        19 punti (75%)


STRATEGIE PER RAGGIUNGERE IL VOTO
------------------------

❌ NON SUPERATO (< 19 punti):
   Solo task obbligatorio (6 punti) - serve almeno 13 punti dai consigliati

✅ MINIMO / SUPERATO (19-20 punti):
   Task 1 (6) + Task 2-3 (4) + Task 4-5 (4) + Task 6 (2) = 16 punti
   oppure
   Task 1 (6) + Task 2-4 (6) + Task 7 (2) = 14 punti
   oppure altre combinazioni che raggiungono 19

⭐ BUONO (21-24 punti):
   Task 1 (6) + Task 2-10 (16) = 22 punti

🌟 ECCELLENTE (25-26 punti):
   Task 1 (6) + Task 2-11 (20) = 26 punti (tutti i task)


ORDINE DI IMPLEMENTAZIONE CONSIGLIATO (90 minuti)
------------------------

00:00 - 10:00  → Leggi bene le istruzioni, organizza il piano

10:00 - 30:00  → Task 1 OBBLIGATORIO (6 punti ✓)
                Blocco Stroop funzionante = BASE

30:00 - 50:00  → Task 2-3 (4 punti) - PRIORITY
                Codice ordinato + debugging (essenziali per qualità)

50:00 - 65:00  → Task 4-5 (4 punti) - RECOMMENDED
                Dialogue Box ottimizzata (aiuta il voto)

65:00 - 75:00  → Task 6 (2 punti) - QUICK WIN
                README (rapido, vale 2 punti)

75:00 - 85:00  → Task 7-11 (10 punti) - BONUS
                Features avanzate (se hai ancora tempo)

85:00 - 90:00  → Bug fixing finale e salvataggio


ISTRUZIONI DURANTE L'ESAME
------------------------

STRATEGIA CONSIGLIATA:

Fase 1 (10:00 - 30:00): Completa Task 1
  → 6 punti (ancora non superato)

Fase 2 (30:00 - 50:00): Completa Task 2-5
  → 6 + 8 = 14 punti (ancora non superato)

Fase 3 (50:00 - 65:00): Completa Task 6
  → 14 + 2 = 16 punti (ancora non superato)

Fase 4 (65:00 - 75:00): Completa Task 7-8
  → 16 + 4 = 20 punti (✅ SUPERATO!)

Fase 5 (75:00 - 90:00): Aggiungi Task 9-11
  → 20 + 6 = 26 punti (🌟 ECCELLENTE!)

REGOLE GENERALI:
- Vai il più avanti possibile
- Implementa prima i task obbligatori (Task 1)
- Quando non arrivi ad andare avanti, chiama l'istruttore
- Se trovi un bug, leggi il messaggio di errore e prova a risolverlo
- Quando l'esperimento funziona, crea una cartella "nome.cognome" e conserva l'esperimento
- Chiedi all'istruttore la chiavetta USB per il salvataggio del tuo esperimento


DOMANDE FREQUENTI
------------------------

D: Se non completo tutti i task obbligatori, cosa succede?
R: Completi almeno Task 1 (6 punti). Poi hai bisogno di 13 punti dai consigliati 
   per arrivare a 19 e superare. Es: Task 2-7 = 12 punti (quasi ce la fai).

D: Qual è il percorso MINIMO per superare (19 punti)?
R: Task 1 (6) + Task 2-5 (8) + Task 6 (2) + Task 7 (2) = 18 punti (NO, manca 1!)
   Devi aggiungere 1 punto in più. Es: Task 1 + Task 2-6 + Task 7-8 = 20 punti ✅

D: Posso fare i task in ordine diverso?
R: Sì! Ma è consigliato l'ordine proposto. Task 1 DEVE essere prima di tutto.

D: Se Task 4 o 5 mi sembrano difficili, posso saltarli?
R: Sì, puoi. Ma sono fattibili (20-30 min totali). Conviene farli per il voto.

D: Task 6 (README) è veramente utile?
R: Sì! Vale 2 punti per 15 minuti di lavoro. È un ottimo rapporto punti/tempo.

D: Cosa succede se ho un bug che non riesco a risolvere?
R: Chiama l'istruttore! Spiega il problema e il messaggio di errore.
   Riceverai comunque i punti per il debugging attempt (Task 3).

D: Posso combinare Task 4 e 5 in una sola Dialogue Box?
R: Sì! Una sola Dialogue Box con 3 campi:
   - experimenter_name
   - num_trials
   - do_training
   Risparmi tempo e il codice è più ordinato.

D: Qual è il voto migliore che posso ottenere?
R: 26 punti (100%) se completi TUTTI i task da Task 1 a Task 11.

D: Se raggiungo 19 punti prima di 90 minuti, posso smettere?
R: Sì, hai superato! Ma se vuoi migliorare il voto, continua con i task rimasti.

---

Data: [Inserisci data dell'esame]
Istruttore: [Inserisci nome istruttore]
Contatti: [Inserisci email/contatti]