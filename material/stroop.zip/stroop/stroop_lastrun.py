﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2026.1.3),
    on Thu May  7 18:02:56 2026
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2026.1.3'
expName = 'stroop'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': '',
    'session': '01',
    'practice': '1',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1680, 1050]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data' + os.sep + '%s_%s' % (expInfo['participant'], expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/thomasquettier/Desktop/stroop/stroop_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    # store pilot mode in data file
    thisExp.addData('piloting', PILOTING, priority=priority.LOW)
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('warning')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color='black', colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='norm',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = 'black'
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'norm'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    # Setup iohub experiment
    ioConfig['Experiment'] = dict(filename=thisExp.dataFileName)
    
    # Start ioHub server
    ioServer = io.launchHubServer(window=win, **ioConfig)
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "ISTR_PRACTICE" ---
    istr_practice_txt = visual.TextStim(win=win, name='istr_practice_txt',
        text="Per favore, premi la freccia;\nSINISTRA se il colore è ROSSO\nBASSA se il colore è VERDE\nDESTRA se il colore è BLU\n\nInitiamo con un po' di pratica\n\nPremi qualsiasi tasto per iniziare",
        font='Arial',
        pos=[0, 0], draggable=False, height=0.1, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    istr_practice_kb = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "TRIAL_ITA" ---
    ita_txt = visual.TextStim(win=win, name='ita_txt',
        text='',
        font='Arial',
        pos=[0, 0], draggable=False, height=0.2, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ita_kb = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "FEEDBACK" ---
    # Run 'Begin Experiment' code from msg_code
    # initialisation di variabili 
    msg = '' # per FEEDBACK
    
    feedback_txt = visual.TextStim(win=win, name='feedback_txt',
        text='',
        font='Arial',
        pos=[0, 0], draggable=False, height=0.1, wrapWidth=None, ori=0, 
        color=[1,1,1], colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "ISTR_ESPERIMENTO" ---
    istr_esperimento_txt = visual.TextStim(win=win, name='istr_esperimento_txt',
        text="Ottimo,\n\nAdesso iniziamo l'esperimento, ricordati di premere:\nSINISTRA se il colore è ROSSO\nBASSO se il colore è VERDE\nDESTRA se il colore è BLU\n\n\nPremi qualsiasi tasto per iniziare",
        font='Arial',
        pos=[0, 0], draggable=False, height=0.1, wrapWidth=None, ori=0, 
        color=[1, 1, 1], colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    istr_esperimento_kb = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "TRIAL_ITA" ---
    ita_txt = visual.TextStim(win=win, name='ita_txt',
        text='',
        font='Arial',
        pos=[0, 0], draggable=False, height=0.2, wrapWidth=None, ori=0, 
        color='white', colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=0.0);
    ita_kb = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "grazie" ---
    logo_img = visual.ImageStim(
        win=win,
        name='logo_img', units='pix', 
        image='images/logo.jpeg', mask=None, anchor='center',
        ori=0.0, pos=(0, 150), draggable=False, size=None,
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    grazie_txt = visual.TextStim(win=win, name='grazie_txt',
        text="L'esperimento è finito.\n\nGrazie!",
        font='arial',
        pos=[0, -0.4], draggable=False, height=0.1, wrapWidth=None, ori=0, 
        color=[1, 1, 1], colorSpace='rgb', opacity=1, 
        languageStyle='LTR',
        depth=-1.0);
    grazie_kb = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "ISTR_PRACTICE" ---
    # create an object to store info about Routine ISTR_PRACTICE
    ISTR_PRACTICE = data.Routine(
        name='ISTR_PRACTICE',
        components=[istr_practice_txt, istr_practice_kb],
    )
    ISTR_PRACTICE.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for istr_practice_kb
    istr_practice_kb.keys = []
    istr_practice_kb.rt = []
    _istr_practice_kb_allKeys = []
    # store start times for ISTR_PRACTICE
    ISTR_PRACTICE.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    ISTR_PRACTICE.tStart = globalClock.getTime(format='float')
    ISTR_PRACTICE.status = STARTED
    thisExp.addData('ISTR_PRACTICE.started', ISTR_PRACTICE.tStart)
    ISTR_PRACTICE.maxDuration = None
    # keep track of which components have finished
    ISTR_PRACTICEComponents = ISTR_PRACTICE.components
    for thisComponent in ISTR_PRACTICE.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ISTR_PRACTICE" ---
    thisExp.currentRoutine = ISTR_PRACTICE
    ISTR_PRACTICE.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *istr_practice_txt* updates
        
        # if istr_practice_txt is starting this frame...
        if istr_practice_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            istr_practice_txt.frameNStart = frameN  # exact frame index
            istr_practice_txt.tStart = t  # local t and not account for scr refresh
            istr_practice_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(istr_practice_txt, 'tStartRefresh')  # time at next scr refresh
            # update status
            istr_practice_txt.status = STARTED
            istr_practice_txt.setAutoDraw(True)
        
        # if istr_practice_txt is active this frame...
        if istr_practice_txt.status == STARTED:
            # update params
            pass
        
        # *istr_practice_kb* updates
        
        # if istr_practice_kb is starting this frame...
        if istr_practice_kb.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            istr_practice_kb.frameNStart = frameN  # exact frame index
            istr_practice_kb.tStart = t  # local t and not account for scr refresh
            istr_practice_kb.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(istr_practice_kb, 'tStartRefresh')  # time at next scr refresh
            # update status
            istr_practice_kb.status = STARTED
            # keyboard checking is just starting
            istr_practice_kb.clock.reset()  # now t=0
            istr_practice_kb.clearEvents(eventType='keyboard')
        if istr_practice_kb.status == STARTED:
            theseKeys = istr_practice_kb.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _istr_practice_kb_allKeys.extend(theseKeys)
            if len(_istr_practice_kb_allKeys):
                istr_practice_kb.keys = _istr_practice_kb_allKeys[-1].name  # just the last key pressed
                istr_practice_kb.rt = _istr_practice_kb_allKeys[-1].rt
                istr_practice_kb.duration = _istr_practice_kb_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=ISTR_PRACTICE,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            ISTR_PRACTICE.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if ISTR_PRACTICE.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in ISTR_PRACTICE.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ISTR_PRACTICE" ---
    for thisComponent in ISTR_PRACTICE.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for ISTR_PRACTICE
    ISTR_PRACTICE.tStop = globalClock.getTime(format='float')
    ISTR_PRACTICE.tStopRefresh = tThisFlipGlobal
    thisExp.addData('ISTR_PRACTICE.stopped', ISTR_PRACTICE.tStop)
    thisExp.nextEntry()
    # the Routine "ISTR_PRACTICE" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Trial_training = data.TrialHandler2(
        name='Trial_training',
        nReps=1, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('condizione.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(Trial_training)  # add the loop to the experiment
    thisTrial_training = Trial_training.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_training.rgb)
    if thisTrial_training != None:
        for paramName in thisTrial_training:
            globals()[paramName] = thisTrial_training[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrial_training in Trial_training:
        Trial_training.status = STARTED
        if hasattr(thisTrial_training, 'status'):
            thisTrial_training.status = STARTED
        currentLoop = Trial_training
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_training.rgb)
        if thisTrial_training != None:
            for paramName in thisTrial_training:
                globals()[paramName] = thisTrial_training[paramName]
        
        # --- Prepare to start Routine "TRIAL_ITA" ---
        # create an object to store info about Routine TRIAL_ITA
        TRIAL_ITA = data.Routine(
            name='TRIAL_ITA',
            components=[ita_txt, ita_kb],
        )
        TRIAL_ITA.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        ita_txt.setColor(colore, colorSpace='rgb')
        ita_txt.setText(parola)
        # create starting attributes for ita_kb
        ita_kb.keys = []
        ita_kb.rt = []
        _ita_kb_allKeys = []
        # store start times for TRIAL_ITA
        TRIAL_ITA.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        TRIAL_ITA.tStart = globalClock.getTime(format='float')
        TRIAL_ITA.status = STARTED
        thisExp.addData('TRIAL_ITA.started', TRIAL_ITA.tStart)
        TRIAL_ITA.maxDuration = None
        # keep track of which components have finished
        TRIAL_ITAComponents = TRIAL_ITA.components
        for thisComponent in TRIAL_ITA.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "TRIAL_ITA" ---
        thisExp.currentRoutine = TRIAL_ITA
        TRIAL_ITA.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_training, 'status') and thisTrial_training.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *ita_txt* updates
            
            # if ita_txt is starting this frame...
            if ita_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                ita_txt.frameNStart = frameN  # exact frame index
                ita_txt.tStart = t  # local t and not account for scr refresh
                ita_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ita_txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'ita_txt.started')
                # update status
                ita_txt.status = STARTED
                ita_txt.setAutoDraw(True)
            
            # if ita_txt is active this frame...
            if ita_txt.status == STARTED:
                # update params
                pass
            
            # *ita_kb* updates
            waitOnFlip = False
            
            # if ita_kb is starting this frame...
            if ita_kb.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                ita_kb.frameNStart = frameN  # exact frame index
                ita_kb.tStart = t  # local t and not account for scr refresh
                ita_kb.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ita_kb, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'ita_kb.started')
                # update status
                ita_kb.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(ita_kb.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(ita_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if ita_kb.status == STARTED and not waitOnFlip:
                theseKeys = ita_kb.getKeys(keyList=['left', 'down', 'right'], ignoreKeys=["escape"], waitRelease=False)
                _ita_kb_allKeys.extend(theseKeys)
                if len(_ita_kb_allKeys):
                    ita_kb.keys = _ita_kb_allKeys[-1].name  # just the last key pressed
                    ita_kb.rt = _ita_kb_allKeys[-1].rt
                    ita_kb.duration = _ita_kb_allKeys[-1].duration
                    # was this correct?
                    if (ita_kb.keys == str(corrAns)) or (ita_kb.keys == corrAns):
                        ita_kb.corr = 1
                    else:
                        ita_kb.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=TRIAL_ITA,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                TRIAL_ITA.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if TRIAL_ITA.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in TRIAL_ITA.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "TRIAL_ITA" ---
        for thisComponent in TRIAL_ITA.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for TRIAL_ITA
        TRIAL_ITA.tStop = globalClock.getTime(format='float')
        TRIAL_ITA.tStopRefresh = tThisFlipGlobal
        thisExp.addData('TRIAL_ITA.stopped', TRIAL_ITA.tStop)
        # check responses
        if ita_kb.keys in ['', [], None]:  # No response was made
            ita_kb.keys = None
            # was no response the correct answer?!
            if str(corrAns).lower() == 'none':
               ita_kb.corr = 1;  # correct non-response
            else:
               ita_kb.corr = 0;  # failed to respond (incorrectly)
        # store data for Trial_training (TrialHandler)
        Trial_training.addData('ita_kb.keys',ita_kb.keys)
        Trial_training.addData('ita_kb.corr', ita_kb.corr)
        if ita_kb.keys != None:  # we had a response
            Trial_training.addData('ita_kb.rt', ita_kb.rt)
            Trial_training.addData('ita_kb.duration', ita_kb.duration)
        # the Routine "TRIAL_ITA" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "FEEDBACK" ---
        # create an object to store info about Routine FEEDBACK
        FEEDBACK = data.Routine(
            name='FEEDBACK',
            components=[feedback_txt],
        )
        FEEDBACK.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from msg_code
        # "resp_kb.corr" è ottenuto se trial 
        # routine  "resp_kb" registra la risposta correta
        
        if ita_kb.corr: 
          msg="Bravo! RT=%.3f" %(ita_kb.rt)
          #msg = "Correct! RT={:.3f}".format(resp_kb.rt)
        
        else:
          msg="Oops! non è coretto"
        
        
        feedback_txt.setText(msg)
        # store start times for FEEDBACK
        FEEDBACK.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        FEEDBACK.tStart = globalClock.getTime(format='float')
        FEEDBACK.status = STARTED
        thisExp.addData('FEEDBACK.started', FEEDBACK.tStart)
        FEEDBACK.maxDuration = None
        # keep track of which components have finished
        FEEDBACKComponents = FEEDBACK.components
        for thisComponent in FEEDBACK.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "FEEDBACK" ---
        thisExp.currentRoutine = FEEDBACK
        FEEDBACK.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 1.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrial_training, 'status') and thisTrial_training.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *feedback_txt* updates
            
            # if feedback_txt is starting this frame...
            if feedback_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                feedback_txt.frameNStart = frameN  # exact frame index
                feedback_txt.tStart = t  # local t and not account for scr refresh
                feedback_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(feedback_txt, 'tStartRefresh')  # time at next scr refresh
                # update status
                feedback_txt.status = STARTED
                feedback_txt.setAutoDraw(True)
            
            # if feedback_txt is active this frame...
            if feedback_txt.status == STARTED:
                # update params
                pass
            
            # if feedback_txt is stopping this frame...
            if feedback_txt.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > feedback_txt.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    feedback_txt.tStop = t  # not accounting for scr refresh
                    feedback_txt.tStopRefresh = tThisFlipGlobal  # on global time
                    feedback_txt.frameNStop = frameN  # exact frame index
                    # update status
                    feedback_txt.status = FINISHED
                    feedback_txt.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=FEEDBACK,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                FEEDBACK.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if FEEDBACK.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in FEEDBACK.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "FEEDBACK" ---
        for thisComponent in FEEDBACK.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for FEEDBACK
        FEEDBACK.tStop = globalClock.getTime(format='float')
        FEEDBACK.tStopRefresh = tThisFlipGlobal
        thisExp.addData('FEEDBACK.stopped', FEEDBACK.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if FEEDBACK.maxDurationReached:
            routineTimer.addTime(-FEEDBACK.maxDuration)
        elif FEEDBACK.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.000000)
        # mark thisTrial_training as finished
        if hasattr(thisTrial_training, 'status'):
            thisTrial_training.status = FINISHED
        # if awaiting a pause, pause now
        if Trial_training.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            Trial_training.status = STARTED
        thisExp.nextEntry()
        
    # completed 1 repeats of 'Trial_training'
    Trial_training.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if Trial_training.trialList in ([], [None], None):
        params = []
    else:
        params = Trial_training.trialList[0].keys()
    # save data for this loop
    Trial_training.saveAsExcel(filename + '.xlsx', sheetName='Trial_training',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "ISTR_ESPERIMENTO" ---
    # create an object to store info about Routine ISTR_ESPERIMENTO
    ISTR_ESPERIMENTO = data.Routine(
        name='ISTR_ESPERIMENTO',
        components=[istr_esperimento_txt, istr_esperimento_kb],
    )
    ISTR_ESPERIMENTO.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for istr_esperimento_kb
    istr_esperimento_kb.keys = []
    istr_esperimento_kb.rt = []
    _istr_esperimento_kb_allKeys = []
    # store start times for ISTR_ESPERIMENTO
    ISTR_ESPERIMENTO.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    ISTR_ESPERIMENTO.tStart = globalClock.getTime(format='float')
    ISTR_ESPERIMENTO.status = STARTED
    thisExp.addData('ISTR_ESPERIMENTO.started', ISTR_ESPERIMENTO.tStart)
    ISTR_ESPERIMENTO.maxDuration = None
    # keep track of which components have finished
    ISTR_ESPERIMENTOComponents = ISTR_ESPERIMENTO.components
    for thisComponent in ISTR_ESPERIMENTO.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ISTR_ESPERIMENTO" ---
    thisExp.currentRoutine = ISTR_ESPERIMENTO
    ISTR_ESPERIMENTO.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *istr_esperimento_txt* updates
        
        # if istr_esperimento_txt is starting this frame...
        if istr_esperimento_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            istr_esperimento_txt.frameNStart = frameN  # exact frame index
            istr_esperimento_txt.tStart = t  # local t and not account for scr refresh
            istr_esperimento_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(istr_esperimento_txt, 'tStartRefresh')  # time at next scr refresh
            # update status
            istr_esperimento_txt.status = STARTED
            istr_esperimento_txt.setAutoDraw(True)
        
        # if istr_esperimento_txt is active this frame...
        if istr_esperimento_txt.status == STARTED:
            # update params
            pass
        
        # *istr_esperimento_kb* updates
        
        # if istr_esperimento_kb is starting this frame...
        if istr_esperimento_kb.status == NOT_STARTED and t >= 0-frameTolerance:
            # keep track of start time/frame for later
            istr_esperimento_kb.frameNStart = frameN  # exact frame index
            istr_esperimento_kb.tStart = t  # local t and not account for scr refresh
            istr_esperimento_kb.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(istr_esperimento_kb, 'tStartRefresh')  # time at next scr refresh
            # update status
            istr_esperimento_kb.status = STARTED
            # keyboard checking is just starting
            istr_esperimento_kb.clock.reset()  # now t=0
            istr_esperimento_kb.clearEvents(eventType='keyboard')
        if istr_esperimento_kb.status == STARTED:
            theseKeys = istr_esperimento_kb.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _istr_esperimento_kb_allKeys.extend(theseKeys)
            if len(_istr_esperimento_kb_allKeys):
                istr_esperimento_kb.keys = _istr_esperimento_kb_allKeys[-1].name  # just the last key pressed
                istr_esperimento_kb.rt = _istr_esperimento_kb_allKeys[-1].rt
                istr_esperimento_kb.duration = _istr_esperimento_kb_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=ISTR_ESPERIMENTO,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            ISTR_ESPERIMENTO.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if ISTR_ESPERIMENTO.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in ISTR_ESPERIMENTO.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ISTR_ESPERIMENTO" ---
    for thisComponent in ISTR_ESPERIMENTO.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for ISTR_ESPERIMENTO
    ISTR_ESPERIMENTO.tStop = globalClock.getTime(format='float')
    ISTR_ESPERIMENTO.tStopRefresh = tThisFlipGlobal
    thisExp.addData('ISTR_ESPERIMENTO.stopped', ISTR_ESPERIMENTO.tStop)
    thisExp.nextEntry()
    # the Routine "ISTR_ESPERIMENTO" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Trials_loop = data.TrialHandler2(
        name='Trials_loop',
        nReps=1, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('condizione.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(Trials_loop)  # add the loop to the experiment
    thisTrials_loop = Trials_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_loop.rgb)
    if thisTrials_loop != None:
        for paramName in thisTrials_loop:
            globals()[paramName] = thisTrials_loop[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_loop in Trials_loop:
        Trials_loop.status = STARTED
        if hasattr(thisTrials_loop, 'status'):
            thisTrials_loop.status = STARTED
        currentLoop = Trials_loop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_loop.rgb)
        if thisTrials_loop != None:
            for paramName in thisTrials_loop:
                globals()[paramName] = thisTrials_loop[paramName]
        
        # --- Prepare to start Routine "TRIAL_ITA" ---
        # create an object to store info about Routine TRIAL_ITA
        TRIAL_ITA = data.Routine(
            name='TRIAL_ITA',
            components=[ita_txt, ita_kb],
        )
        TRIAL_ITA.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        ita_txt.setColor(colore, colorSpace='rgb')
        ita_txt.setText(parola)
        # create starting attributes for ita_kb
        ita_kb.keys = []
        ita_kb.rt = []
        _ita_kb_allKeys = []
        # store start times for TRIAL_ITA
        TRIAL_ITA.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        TRIAL_ITA.tStart = globalClock.getTime(format='float')
        TRIAL_ITA.status = STARTED
        thisExp.addData('TRIAL_ITA.started', TRIAL_ITA.tStart)
        TRIAL_ITA.maxDuration = None
        # keep track of which components have finished
        TRIAL_ITAComponents = TRIAL_ITA.components
        for thisComponent in TRIAL_ITA.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "TRIAL_ITA" ---
        thisExp.currentRoutine = TRIAL_ITA
        TRIAL_ITA.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_loop, 'status') and thisTrials_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *ita_txt* updates
            
            # if ita_txt is starting this frame...
            if ita_txt.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                ita_txt.frameNStart = frameN  # exact frame index
                ita_txt.tStart = t  # local t and not account for scr refresh
                ita_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ita_txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'ita_txt.started')
                # update status
                ita_txt.status = STARTED
                ita_txt.setAutoDraw(True)
            
            # if ita_txt is active this frame...
            if ita_txt.status == STARTED:
                # update params
                pass
            
            # *ita_kb* updates
            waitOnFlip = False
            
            # if ita_kb is starting this frame...
            if ita_kb.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                ita_kb.frameNStart = frameN  # exact frame index
                ita_kb.tStart = t  # local t and not account for scr refresh
                ita_kb.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ita_kb, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'ita_kb.started')
                # update status
                ita_kb.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(ita_kb.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(ita_kb.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if ita_kb.status == STARTED and not waitOnFlip:
                theseKeys = ita_kb.getKeys(keyList=['left', 'down', 'right'], ignoreKeys=["escape"], waitRelease=False)
                _ita_kb_allKeys.extend(theseKeys)
                if len(_ita_kb_allKeys):
                    ita_kb.keys = _ita_kb_allKeys[-1].name  # just the last key pressed
                    ita_kb.rt = _ita_kb_allKeys[-1].rt
                    ita_kb.duration = _ita_kb_allKeys[-1].duration
                    # was this correct?
                    if (ita_kb.keys == str(corrAns)) or (ita_kb.keys == corrAns):
                        ita_kb.corr = 1
                    else:
                        ita_kb.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=TRIAL_ITA,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                TRIAL_ITA.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if TRIAL_ITA.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in TRIAL_ITA.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "TRIAL_ITA" ---
        for thisComponent in TRIAL_ITA.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for TRIAL_ITA
        TRIAL_ITA.tStop = globalClock.getTime(format='float')
        TRIAL_ITA.tStopRefresh = tThisFlipGlobal
        thisExp.addData('TRIAL_ITA.stopped', TRIAL_ITA.tStop)
        # check responses
        if ita_kb.keys in ['', [], None]:  # No response was made
            ita_kb.keys = None
            # was no response the correct answer?!
            if str(corrAns).lower() == 'none':
               ita_kb.corr = 1;  # correct non-response
            else:
               ita_kb.corr = 0;  # failed to respond (incorrectly)
        # store data for Trials_loop (TrialHandler)
        Trials_loop.addData('ita_kb.keys',ita_kb.keys)
        Trials_loop.addData('ita_kb.corr', ita_kb.corr)
        if ita_kb.keys != None:  # we had a response
            Trials_loop.addData('ita_kb.rt', ita_kb.rt)
            Trials_loop.addData('ita_kb.duration', ita_kb.duration)
        # the Routine "TRIAL_ITA" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisTrials_loop as finished
        if hasattr(thisTrials_loop, 'status'):
            thisTrials_loop.status = FINISHED
        # if awaiting a pause, pause now
        if Trials_loop.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            Trials_loop.status = STARTED
        thisExp.nextEntry()
        
    # completed 1 repeats of 'Trials_loop'
    Trials_loop.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if Trials_loop.trialList in ([], [None], None):
        params = []
    else:
        params = Trials_loop.trialList[0].keys()
    # save data for this loop
    Trials_loop.saveAsExcel(filename + '.xlsx', sheetName='Trials_loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "grazie" ---
    # create an object to store info about Routine grazie
    grazie = data.Routine(
        name='grazie',
        components=[logo_img, grazie_txt, grazie_kb],
    )
    grazie.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for grazie_kb
    grazie_kb.keys = []
    grazie_kb.rt = []
    _grazie_kb_allKeys = []
    # store start times for grazie
    grazie.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    grazie.tStart = globalClock.getTime(format='float')
    grazie.status = STARTED
    thisExp.addData('grazie.started', grazie.tStart)
    grazie.maxDuration = None
    # keep track of which components have finished
    grazieComponents = grazie.components
    for thisComponent in grazie.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "grazie" ---
    thisExp.currentRoutine = grazie
    grazie.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *logo_img* updates
        
        # if logo_img is starting this frame...
        if logo_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            logo_img.frameNStart = frameN  # exact frame index
            logo_img.tStart = t  # local t and not account for scr refresh
            logo_img.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(logo_img, 'tStartRefresh')  # time at next scr refresh
            # update status
            logo_img.status = STARTED
            logo_img.setAutoDraw(True)
        
        # if logo_img is active this frame...
        if logo_img.status == STARTED:
            # update params
            pass
        
        # *grazie_txt* updates
        
        # if grazie_txt is starting this frame...
        if grazie_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            grazie_txt.frameNStart = frameN  # exact frame index
            grazie_txt.tStart = t  # local t and not account for scr refresh
            grazie_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(grazie_txt, 'tStartRefresh')  # time at next scr refresh
            # update status
            grazie_txt.status = STARTED
            grazie_txt.setAutoDraw(True)
        
        # if grazie_txt is active this frame...
        if grazie_txt.status == STARTED:
            # update params
            pass
        
        # *grazie_kb* updates
        
        # if grazie_kb is starting this frame...
        if grazie_kb.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            grazie_kb.frameNStart = frameN  # exact frame index
            grazie_kb.tStart = t  # local t and not account for scr refresh
            grazie_kb.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(grazie_kb, 'tStartRefresh')  # time at next scr refresh
            # update status
            grazie_kb.status = STARTED
            # keyboard checking is just starting
            grazie_kb.clock.reset()  # now t=0
            grazie_kb.clearEvents(eventType='keyboard')
        if grazie_kb.status == STARTED:
            theseKeys = grazie_kb.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _grazie_kb_allKeys.extend(theseKeys)
            if len(_grazie_kb_allKeys):
                grazie_kb.keys = _grazie_kb_allKeys[-1].name  # just the last key pressed
                grazie_kb.rt = _grazie_kb_allKeys[-1].rt
                grazie_kb.duration = _grazie_kb_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=grazie,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            grazie.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if grazie.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in grazie.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "grazie" ---
    for thisComponent in grazie.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for grazie
    grazie.tStop = globalClock.getTime(format='float')
    grazie.tStopRefresh = tThisFlipGlobal
    thisExp.addData('grazie.stopped', grazie.tStop)
    thisExp.nextEntry()
    # the Routine "grazie" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    # stop any playback components
    if thisExp.currentRoutine is not None:
        for comp in thisExp.currentRoutine.getPlaybackComponents():
            comp.stop()
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
