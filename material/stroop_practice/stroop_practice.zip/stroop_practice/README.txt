 Experiment:     	STROOP ITA 1.0
============================================================
 Programmer:     	Thomas Quettier
============================================================
 Date:           	19/10/2022
============================================================
 Description:    	Stroop test con PsychoPy
============================================================

ATTENZIONE
------------------------
Lo stroop test:
- E' in lingua italiana
- Usa le parole/colore: **VERDE, ROSSO, BLU**
- Prevede un feedback solo nel blocco di allenamento
- Il blocco di allenamento si può evitare con impostazione pari a 0
- Il file *condizione.xlsx* contiene 12 trials

Psychopy3 Version:
------------------------
V2022.1.4

References
------------------------

Stroop, John Ridley (1935). "Studies of interference in serial verbal reactions". Journal of Experimental Psychology. 18 (6): 643–662.
MacLeod, CM (1991). "Half a century of research on the Stroop effect: an integrative review". Psychological Bulletin. 109 (2): 163–203.
