 Experiment:     	STROOP ENG ITA 1.1
============================================================
 Programmer:     	Thomas Quettier
============================================================
 Date:           	18/04/2023
============================================================
 Description:    	Stroop biligual test con PsychoPy
============================================================

ATTENZIONE
------------------------

Il test è in lingua Italiana ed Inglese ed è pensato per partecipanti Italiani.
Tutte le istruzioni sono in Italiano

L'esperimento è controbilanciato in base al numero dei partecipanti
Il training e opzionale (definire in dialogue box)

Eng e ita definiscono il numero di trial in ogni blocco. (trials N = x * 6)




Version updating:
------------------------
1.0 troop eng + ita
1.1 controbilanciato
