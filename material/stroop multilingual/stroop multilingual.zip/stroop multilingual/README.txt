#################################################
# 
# Experiment:     	STROOP ENG ITA
# Programmer:     	Thomas Quettier
# Date:           	17/10/2023
# Description:    	Stroop test con PsychoPy
#
#################################################

ATTENZIONE:

Il test è in lingua italiana o in lingua inglese
I colori Blue Rosso e Verde sono usati.


#################################################

Version updating:
