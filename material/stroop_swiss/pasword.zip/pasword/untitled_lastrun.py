﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.1.4),
    on Thu Apr 20 21:33:12 2023
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.1.4'
expName = 'untitled'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/thomasquettier/Desktop/pasword/untitled_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1680, 1050], fullscr=False, screen=0, 
    winType='pyglet', allowGUI=True, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# Setup ioHub
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# Initialize components for Routine "PW_LOOP"
PW_LOOPClock = core.Clock()
textbox = visual.TextBox2(
     win, text='Password:', font='Open Sans',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0, alignment='center',
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False, languageStyle='LTR',
     editable=True,
     name='textbox',
     autoLog=True,
)

# Initialize components for Routine "bingo"
bingoClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='Funziona!',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "PW_ROUTINE"
PW_ROUTINEClock = core.Clock()
txt_password = visual.TextStim(win=win, name='txt_password',
    text='Inserire password:',
    font='Open Sans',
    units='cm', pos=(0, 1), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
textbox_password = visual.TextBox2(
     win, text=None, font='Open Sans',
     pos=(0,-1),units='cm',     letterHeight=0.8,
     size=(5, 1), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=0.7,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0, alignment='center-left',
     anchor='center',
     fillColor=None, borderColor='black',
     flipHoriz=False, flipVert=False, languageStyle='LTR',
     editable=True,
     name='textbox_password',
     autoLog=True,
)

# Initialize components for Routine "bingo"
bingoClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='Funziona!',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "PW_BUTTON"
PW_BUTTONClock = core.Clock()
textbox_button = visual.TextBox2(
     win, text=None, font='Open Sans',
     pos=(0, 0),units='cm',     letterHeight=0.7,
     size=(5, 1), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0, alignment='center',
     anchor='center',
     fillColor=None, borderColor='white',
     flipHoriz=False, flipVert=False, languageStyle='LTR',
     editable=True,
     name='textbox_button',
     autoLog=True,
)
button = visual.ButtonStim(win, 
    text='ok', font='Arvo',
    pos=(0, -3),units='cm',
    letterHeight=1.0,
    size=(2,1), borderWidth=0.0,
    fillColor='darkgrey', borderColor=None,
    color='white', colorSpace='rgb',
    opacity=None,
    bold=True, italic=False,
    padding=None,
    anchor='center',
    name='button'
)
button.buttonClock = core.Clock()
mouse_button = event.Mouse(win=win)
x, y = [None, None]
mouse_button.mouseClock = core.Clock()

# Initialize components for Routine "bingo"
bingoClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='Funziona!',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# set up handler to look after randomisation of conditions etc
Loop_password = data.TrialHandler(nReps=0.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Loop_password')
thisExp.addLoop(Loop_password)  # add the loop to the experiment
thisLoop_password = Loop_password.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoop_password.rgb)
if thisLoop_password != None:
    for paramName in thisLoop_password:
        exec('{} = thisLoop_password[paramName]'.format(paramName))

for thisLoop_password in Loop_password:
    currentLoop = Loop_password
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_password.rgb)
    if thisLoop_password != None:
        for paramName in thisLoop_password:
            exec('{} = thisLoop_password[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "PW_LOOP"-------
    continueRoutine = True
    # update component parameters for each repeat
    textbox.reset()
    # keep track of which components have finished
    PW_LOOPComponents = [textbox]
    for thisComponent in PW_LOOPComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    PW_LOOPClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "PW_LOOP"-------
    while continueRoutine:
        # get current time
        t = PW_LOOPClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=PW_LOOPClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        if textbox.text == str("Password:thomas"):
            core.wait(2)
            continueRoutine = False
            Loop_password.finished = True
        
        
        # *textbox* updates
        if textbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            textbox.frameNStart = frameN  # exact frame index
            textbox.tStart = t  # local t and not account for scr refresh
            textbox.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(textbox, 'tStartRefresh')  # time at next scr refresh
            textbox.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in PW_LOOPComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "PW_LOOP"-------
    for thisComponent in PW_LOOPComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Loop_password.addData('textbox.text',textbox.text)
    Loop_password.addData('textbox.started', textbox.tStartRefresh)
    Loop_password.addData('textbox.stopped', textbox.tStopRefresh)
    # the Routine "PW_LOOP" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 0.0 repeats of 'Loop_password'


# ------Prepare to start Routine "bingo"-------
continueRoutine = True
routineTimer.add(1.000000)
# update component parameters for each repeat
# keep track of which components have finished
bingoComponents = [text]
for thisComponent in bingoComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
bingoClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "bingo"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = bingoClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=bingoClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    if text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text.tStartRefresh + 1.0-frameTolerance:
            # keep track of stop time/frame for later
            text.tStop = t  # not accounting for scr refresh
            text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
            text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in bingoComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "bingo"-------
for thisComponent in bingoComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)

# ------Prepare to start Routine "PW_ROUTINE"-------
continueRoutine = True
# update component parameters for each repeat
bufferTime=1
clickClock=core.Clock()
thisTime = 0
lastTime = 0

password = "thomas"
textbox_password.reset()
# keep track of which components have finished
PW_ROUTINEComponents = [txt_password, textbox_password]
for thisComponent in PW_ROUTINEComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
PW_ROUTINEClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "PW_ROUTINE"-------
while continueRoutine:
    # get current time
    t = PW_ROUTINEClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=PW_ROUTINEClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    # check pw ogni sec
    thisTime = clickClock.getTime()
    
    if (thisTime - lastTime) > bufferTime:
        if textbox_password.text == str(password):
            continueRoutine = False
            routineForceEnded = True
        else:
            lastTime = thisTime
    
    
    
    # *txt_password* updates
    if txt_password.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        txt_password.frameNStart = frameN  # exact frame index
        txt_password.tStart = t  # local t and not account for scr refresh
        txt_password.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(txt_password, 'tStartRefresh')  # time at next scr refresh
        txt_password.setAutoDraw(True)
    
    # *textbox_password* updates
    if textbox_password.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        textbox_password.frameNStart = frameN  # exact frame index
        textbox_password.tStart = t  # local t and not account for scr refresh
        textbox_password.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(textbox_password, 'tStartRefresh')  # time at next scr refresh
        textbox_password.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in PW_ROUTINEComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "PW_ROUTINE"-------
for thisComponent in PW_ROUTINEComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('txt_password.started', txt_password.tStartRefresh)
thisExp.addData('txt_password.stopped', txt_password.tStopRefresh)
thisExp.addData('textbox_password.text',textbox_password.text)
thisExp.addData('textbox_password.started', textbox_password.tStartRefresh)
thisExp.addData('textbox_password.stopped', textbox_password.tStopRefresh)
# the Routine "PW_ROUTINE" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "bingo"-------
continueRoutine = True
routineTimer.add(1.000000)
# update component parameters for each repeat
# keep track of which components have finished
bingoComponents = [text]
for thisComponent in bingoComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
bingoClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "bingo"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = bingoClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=bingoClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    if text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text.tStartRefresh + 1.0-frameTolerance:
            # keep track of stop time/frame for later
            text.tStop = t  # not accounting for scr refresh
            text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
            text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in bingoComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "bingo"-------
for thisComponent in bingoComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)

# set up handler to look after randomisation of conditions etc
Loop_pw_button = data.TrialHandler(nReps=100.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Loop_pw_button')
thisExp.addLoop(Loop_pw_button)  # add the loop to the experiment
thisLoop_pw_button = Loop_pw_button.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoop_pw_button.rgb)
if thisLoop_pw_button != None:
    for paramName in thisLoop_pw_button:
        exec('{} = thisLoop_pw_button[paramName]'.format(paramName))

for thisLoop_pw_button in Loop_pw_button:
    currentLoop = Loop_pw_button
    # abbreviate parameter names if possible (e.g. rgb = thisLoop_pw_button.rgb)
    if thisLoop_pw_button != None:
        for paramName in thisLoop_pw_button:
            exec('{} = thisLoop_pw_button[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "PW_BUTTON"-------
    continueRoutine = True
    # update component parameters for each repeat
    textbox_button.reset()
    # setup some python lists for storing info about the mouse_button
    mouse_button.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    PW_BUTTONComponents = [textbox_button, button, mouse_button]
    for thisComponent in PW_BUTTONComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    PW_BUTTONClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "PW_BUTTON"-------
    while continueRoutine:
        # get current time
        t = PW_BUTTONClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=PW_BUTTONClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *textbox_button* updates
        if textbox_button.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            textbox_button.frameNStart = frameN  # exact frame index
            textbox_button.tStart = t  # local t and not account for scr refresh
            textbox_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(textbox_button, 'tStartRefresh')  # time at next scr refresh
            textbox_button.setAutoDraw(True)
        
        # *button* updates
        if button.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            button.frameNStart = frameN  # exact frame index
            button.tStart = t  # local t and not account for scr refresh
            button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(button, 'tStartRefresh')  # time at next scr refresh
            button.setAutoDraw(True)
        if button.status == STARTED:
            # check whether button has been pressed
            if button.isClicked:
                if not button.wasClicked:
                    button.timesOn.append(button.buttonClock.getTime()) # store time of first click
                    button.timesOff.append(button.buttonClock.getTime()) # store time clicked until
                else:
                    button.timesOff[-1] = button.buttonClock.getTime() # update time clicked until
                if not button.wasClicked:
                    continueRoutine = False  # end routine when button is clicked
                    None
                button.wasClicked = True  # if button is still clicked next frame, it is not a new click
            else:
                button.wasClicked = False  # if button is clicked next frame, it is a new click
        else:
            button.wasClicked = False  # if button is clicked next frame, it is a new click
        # *mouse_button* updates
        if mouse_button.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse_button.frameNStart = frameN  # exact frame index
            mouse_button.tStart = t  # local t and not account for scr refresh
            mouse_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse_button, 'tStartRefresh')  # time at next scr refresh
            mouse_button.status = STARTED
            mouse_button.mouseClock.reset()
            prevButtonState = mouse_button.getPressed()  # if button is down already this ISN'T a new click
        if mouse_button.status == STARTED:  # only update if started and not finished!
            buttons = mouse_button.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter(button)
                        clickableList = button
                    except:
                        clickableList = [button]
                    for obj in clickableList:
                        if obj.contains(mouse_button):
                            gotValidClick = True
                            mouse_button.clicked_name.append(obj.name)
                    if gotValidClick:  
                        continueRoutine = False  # abort routine on response
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in PW_BUTTONComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "PW_BUTTON"-------
    for thisComponent in PW_BUTTONComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    if textbox_button.text == str("thomas"):
        Loop_pw_button.finished = True
    else:
        Loop_pw_button.finished = False
        
    print(Loop_pw_button.thisRepN)
    Loop_pw_button.addData('textbox_button.text',textbox_button.text)
    Loop_pw_button.addData('textbox_button.started', textbox_button.tStartRefresh)
    Loop_pw_button.addData('textbox_button.stopped', textbox_button.tStopRefresh)
    Loop_pw_button.addData('button.started', button.tStartRefresh)
    Loop_pw_button.addData('button.stopped', button.tStopRefresh)
    Loop_pw_button.addData('button.numClicks', button.numClicks)
    if button.numClicks:
       Loop_pw_button.addData('button.timesOn', button.timesOn)
       Loop_pw_button.addData('button.timesOff', button.timesOff)
    else:
       Loop_pw_button.addData('button.timesOn', "")
       Loop_pw_button.addData('button.timesOff', "")
    # store data for Loop_pw_button (TrialHandler)
    x, y = mouse_button.getPos()
    buttons = mouse_button.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        try:
            iter(button)
            clickableList = button
        except:
            clickableList = [button]
        for obj in clickableList:
            if obj.contains(mouse_button):
                gotValidClick = True
                mouse_button.clicked_name.append(obj.name)
    Loop_pw_button.addData('mouse_button.x', x)
    Loop_pw_button.addData('mouse_button.y', y)
    Loop_pw_button.addData('mouse_button.leftButton', buttons[0])
    Loop_pw_button.addData('mouse_button.midButton', buttons[1])
    Loop_pw_button.addData('mouse_button.rightButton', buttons[2])
    if len(mouse_button.clicked_name):
        Loop_pw_button.addData('mouse_button.clicked_name', mouse_button.clicked_name[0])
    Loop_pw_button.addData('mouse_button.started', mouse_button.tStart)
    Loop_pw_button.addData('mouse_button.stopped', mouse_button.tStop)
    # the Routine "PW_BUTTON" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 100.0 repeats of 'Loop_pw_button'


# ------Prepare to start Routine "bingo"-------
continueRoutine = True
routineTimer.add(1.000000)
# update component parameters for each repeat
# keep track of which components have finished
bingoComponents = [text]
for thisComponent in bingoComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
bingoClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "bingo"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = bingoClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=bingoClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    if text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text.tStartRefresh + 1.0-frameTolerance:
            # keep track of stop time/frame for later
            text.tStop = t  # not accounting for scr refresh
            text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
            text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in bingoComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "bingo"-------
for thisComponent in bingoComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
